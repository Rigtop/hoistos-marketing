# HoistOS Empire Pack v2

You just downloaded 35 skills. Here is how to install in your tier.

Bundle version: 2.0.0. Build date: 2026-05-12.

## 1. Pick your tier

Three install paths, one bundle. Pick the one that matches your Claude account.

| Tier | Who it is | Install file |
|---|---|---|
| Pro (claude.ai web) | Most operators. $20/month. Project Knowledge paste install. | INSTALL-PRO.md |
| Max (Claude desktop app) | Power web users. Desktop blank-chat launch or paste. | INSTALL-MAX.sh |
| Code (Claude Code CLI) | Engineers. Filesystem skill install at `~/.claude/skills/`. | INSTALL-CODE.sh |

Not sure which tier you have? If you log into claude.ai in a browser, you are Pro or Max. If you run `claude` in a terminal, you are Code. Both can be true. Pick whichever you use most.

## 2. Per-tier install

### Pro tier (Project Knowledge paste)

Open `INSTALL-PRO.md`. It walks you through opening claude.ai, finding your Project, and pasting each `SKILL.md` block into Project Knowledge. About 5 minutes per pack. Save after each paste so the work is not lost on a tab close.

### Max desktop tier (copy and paste)

Run `bash INSTALL-MAX.sh` from a terminal. It opens hoistos.com so you can use the per-pack copy buttons. The page opens Claude desktop to a blank chat, copies the pack, and you paste with Cmd+V or Ctrl+V.

### Code tier (filesystem)

Run `bash INSTALL-CODE.sh` from a terminal. It copies every `skills/<name>/` folder into `~/.claude/skills/`. Existing skills with the same name are left alone unless you pass `--overwrite`. Run `bash setup-verify.sh` after.

## 3. What you got: 35 packs

| Pack | Tier default | Skills | Install minutes |
|---|---|---|---|
| `foundation-01-constitution` | Pro | constitution-loader, voice-guard, banned-pattern-sweep | 5 |
| `foundation-02-facts-registry` | Pro | facts-registry-loader, facts-query, facts-staleness-checker | 5 |
| `foundation-03-cold-start-protocol` | Pro | cold-start-verify, session-briefing-builder, cold-start-stamp | 5 |
| `foundation-04-decision-log` | Pro / Max / Code | log-decision, recall-decisions, decisions-by-quarter | 5 |
| `foundation-05-skill-builder` | Pro / Max / Code | build-skill, validate-skill, list-my-skills | 5 |
| `foundation-06-routing-rules` | Pro / Max / Code | route-deliverable, routing-audit, routing-suggest | 12 |
| `foundation-07-memory-architecture` | Pro / Max / Code | capture-memory, recall-memory, memory-audit | 11 |
| `foundation-08-source-sweep` | Pro / Max / Code | source-sweep, stamp-sources, tier-down-sources | 5 |
| `foundation-09-output-validator` | Code | output-validator, validate-output, self-check, pre-send-email-gate | 5 |
| `foundation-10-email-playbook` | Pro / Max / Code | classify-audience, draft-email, email-pre-send-gate, thread-summarize | 6 |
| `foundation-11-notion-write-gate` | Pro / Max / Code | notion-write-with-verify, declare-expected-state, notion-state-diff, notion-auto-remediate | 5 |
| `intro-00-tier-guide` | Pro / Max / Code | tier-detector, install-path-router, first-pack-recommender | 5 |
| `beg-01-chat-to-projects` | Pro | chat-to-projects, personal-cos, email-drafter, meeting-summarizer | 5 |
| `beg-02-desktop-organizer` | Pro | desktop-organizer, file-search, jobsite-photo-router | 17 |
| `beg-03-voice-to-task` | Pro | voice-to-task, task-search, daily-priority-roller | 7 |
| `beg-04-first-skill-bootstrap` | Pro | first-custom-skill, skill-tester, skill-versioner | 8 |
| `mid-01-email-playbook-tier-aware` | {{CLAUDE_TIER}} | email-playbook, email-classifier, email-followup-tracker | 9 |
| `mid-02-expense-automation` | {{CLAUDE_TIER}} | expense-automation, receipt-finder, gl-coder | 11 |
| `mid-03-daily-briefing` | {{CLAUDE_TIER}} | daily-briefing, evening-wrap-up, context-loader | 10 |
| `mid-04-knowledge-search` | {{CLAUDE_TIER}} | knowledge-search, decision-recall, cross-source-search | 8 |
| `adv-01-proposal-builder` | Pro / Max / Code | proposal-builder, gc-quirk-library, cover-letter-drafter | 8 |
| `adv-02-meeting-to-tasks` | Pro / Max / Code | meeting-to-tasks, attendee-roster-resolver, notion-task-writer | 9 |
| `adv-03-contract-review` | Pro / Max / Code | contract-review, state-statute-flagger, redline-drafter | 9 |
| `adv-04-skill-creator-meta` | Pro / Max / Code | skill-creator-meta, workflow-validator, voice-enforcer | 8 |
| `pow-01-cold-start-protocol` | Code | cold-start-verify, identity-stamp, rules-enforcer | 10 |
| `pow-02-rag-knowledge-search` | Code | knowledge-search, corpus-reindex, citation-formatter | 12 |
| `pow-04-multi-model-jury` | Code | multi-model-jury | 8 |
| `biz-01-notion-mcp-setup` | Pro / Max / Code | notion-mcp-bootstrap, notion-rollup-explain, notion-database-suggest | 8 |
| `biz-02-email-to-notion-intel` | Pro / Max / Code | email-classify, email-to-notion-write, synthesis-rollup, weekly-intelligence-brief | 10 |
| `biz-03-email-triage-responder` | Code | email-scan, email-triage-rank, email-draft, morning-email-routine | 6 |
| `biz-04-team-ai-enablement` | Code | rollout-projects, starter-skill-kit, skill-share, adoption-metrics | 7 |
| `biz-05-document-prep-engine` | Pro / Max / Code | build-perennial-doc, doc-review-perennial-standard, kpi-card-builder, doc-bluf | 9 |
| `biz-06-proposal-heavy` | Pro / Max / Code | embedded | 12 |
| `biz-07-proposal-light` | Pro / Max / Code | proposal-light, build-proposal-light, change-order-draft, pricing-quick, proposal-light-send | 7 |
| `biz-08-bd-ai-training` | Pro / Max / Code | bd-ai-training, load-bd-session, bd-homework-tracker, bd-skill-deploy, bd-progress-report | 9 |

Total install time if you do every pack: about 281 minutes. Realistically you do not install all 35 in one sitting. Pick 3 from the Foundation tier, run them this week, come back for more.

## 4. Verify install

Open a fresh Claude chat in the Project where you installed the packs. Paste this exact prompt:

```
Smoke test. List every Skill or Project Knowledge block you can see in this chat. For each one, give me the name and one sentence on what it does. Do not invent any.
```

What you should see back: a list of the skills you just installed, named correctly, one sentence each. If the list is shorter than the count of packs you installed, the install did not register all of them. Re-run the install for the missing ones.

On Code tier you can also run `bash setup-verify.sh` from inside the unpacked bundle. It prints the pack count, the installed skill count under `~/.claude/skills/`, and runs a smoke test on the first skill.

## 5. Get help

Stuck on a pack? Open the pack's `.md` file in `packs/`. Each one ships with a `Common breaks and how to fix` section. If that does not solve it, the timeline page on `hoistos.com` has the same content with copy buttons and browser fallback.

Routing manifest: `routing-manifest.json` lists every pack, every skill name, every install path, every tier default. If you want to script the install, that is the file to read.

Built by Perennial Empire and HoistOS. Confidence: high.
