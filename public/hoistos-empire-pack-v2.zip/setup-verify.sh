#!/usr/bin/env bash
# setup-verify.sh
# Post-install smoke test. Prints pack count, installed skill count, and runs a
# first-skill smoke test (cats the first SKILL.md frontmatter).
set -euo pipefail

BUNDLE_DIR="$(cd "$(dirname "$0")" && pwd)"
PACKS="$BUNDLE_DIR/packs"
SKILLS_DST="$HOME/.claude/skills"

echo "HoistOS Empire Pack v2 - setup verify"
echo "Bundle: $BUNDLE_DIR"
echo ""

pack_count=$(find "$PACKS" -maxdepth 1 -name "*.md" | wc -l | tr -d " ")
echo "Packs in bundle:        $pack_count"

if [[ -d "$SKILLS_DST" ]]; then
  installed=$(find "$SKILLS_DST" -maxdepth 2 -name "SKILL.md" | wc -l | tr -d " ")
  echo "Skills installed:       $installed (in $SKILLS_DST)"
else
  echo "Skills installed:       0 (no $SKILLS_DST directory)"
fi
echo ""

first_skill_dir=$(find "$BUNDLE_DIR/skills" -mindepth 1 -maxdepth 1 -type d | head -1)
if [[ -n "$first_skill_dir" ]]; then
  first_name="$(basename "$first_skill_dir")"
  echo "Smoke test: first skill in bundle is $first_name"
  echo "  Bundle path:  $first_skill_dir/SKILL.md"
  if [[ -f "$SKILLS_DST/$first_name/SKILL.md" ]]; then
    echo "  Install path: $SKILLS_DST/$first_name/SKILL.md (PRESENT)"
    echo ""
    echo "  Frontmatter from installed copy:"
    head -10 "$SKILLS_DST/$first_name/SKILL.md" | sed "s/^/    /"
  else
    echo "  Install path: $SKILLS_DST/$first_name/SKILL.md (MISSING)"
    echo "  If you are on Code tier: run bash INSTALL-CODE.sh first."
    echo "  If you are on Pro or Max: this is expected. Verify via the smoke prompt"
    echo "  in README.md Section 4."
  fi
else
  echo "No skills/ folder in bundle. Bundle may be corrupt."
fi
echo ""
echo "Done. If counts look wrong, re-run bundle-build.sh and reinstall."
