#!/usr/bin/env bash
# INSTALL-CODE.sh
# Code tier install: copies every skills/<name>/ folder from this bundle into
# ~/.claude/skills/. Existing skills with the same name are left alone unless
# --overwrite is passed. Idempotent. Offline.
set -euo pipefail

BUNDLE_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILLS_SRC="$BUNDLE_DIR/skills"
SKILLS_DST="$HOME/.claude/skills"
OVERWRITE=0

for arg in "$@"; do
  if [[ "$arg" == "--overwrite" ]]; then
    OVERWRITE=1
  fi
done

if [[ ! -d "$SKILLS_SRC" ]]; then
  echo "ERROR: skills/ not found at $SKILLS_SRC. Bundle may be corrupt." >&2
  exit 1
fi

mkdir -p "$SKILLS_DST"
echo "[INSTALL-CODE] source: $SKILLS_SRC"
echo "[INSTALL-CODE] dest:   $SKILLS_DST"
echo "[INSTALL-CODE] overwrite: $OVERWRITE"
echo ""

installed=0
skipped=0
for src in "$SKILLS_SRC"/*/; do
  [[ -d "$src" ]] || continue
  name="$(basename "$src")"
  dst="$SKILLS_DST/$name"
  if [[ -d "$dst" && "$OVERWRITE" -eq 0 ]]; then
    echo "  [skip] $name (already installed; pass --overwrite to replace)"
    skipped=$((skipped + 1))
    continue
  fi
  mkdir -p "$dst"
  cp -R "$src"* "$dst/"
  echo "  [ok]   $name"
  installed=$((installed + 1))
done

echo ""
echo "[INSTALL-CODE] installed: $installed"
echo "[INSTALL-CODE] skipped:   $skipped"
echo ""
echo "Run bash setup-verify.sh next to confirm the install."
