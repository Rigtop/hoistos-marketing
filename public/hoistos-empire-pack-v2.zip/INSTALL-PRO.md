# INSTALL-PRO.md

Pro tier install: paste each SKILL.md block into Claude.ai Project Knowledge. About 5 minutes per pack.

## 1. Open your Project

Open `claude.ai` in a desktop browser. Sign in. Click the Projects tab in the left sidebar. Open the Project you want these skills installed in, or click `Create project` and name it `[Your name]'s Workspace`.

## 2. Open Project Knowledge

Inside the Project, look at the right side panel. Find the section labeled `Project knowledge`. That is the text box you paste into.

## 3. Paste packs in this order

Recommended order: Foundation packs first (they set voice + identity + routing), then pick the chronological packs that match what you want to do.

For each pack:

1. Open the pack file from `packs/` in this bundle (any text editor, or VS Code).
2. Find the section labeled `## Skill: <name>` or `Artifact: ~/.claude/skills/<name>/SKILL.md`. That fenced block is the SKILL.md body.
3. Copy the entire fenced block including the YAML frontmatter (`---` to `---`).
4. Paste it into the Project Knowledge text box on claude.ai.
5. Click `Save`.
6. Open a fresh chat in this Project to confirm the skill is loaded.

## Pack list

### `foundation-01-constitution`

- Tier default: Pro
- Skills to paste: constitution-loader, voice-guard, banned-pattern-sweep
- Pack file: `packs/foundation-01-constitution.md`
- Install minutes: ~5

### `foundation-02-facts-registry`

- Tier default: Pro
- Skills to paste: facts-registry-loader, facts-query, facts-staleness-checker
- Pack file: `packs/foundation-02-facts-registry.md`
- Install minutes: ~5

### `foundation-03-cold-start-protocol`

- Tier default: Pro
- Skills to paste: cold-start-verify, session-briefing-builder, cold-start-stamp
- Pack file: `packs/foundation-03-cold-start-protocol.md`
- Install minutes: ~5

### `foundation-04-decision-log`

- Tier default: Pro / Max / Code
- Skills to paste: log-decision, recall-decisions, decisions-by-quarter
- Pack file: `packs/foundation-04-decision-log.md`
- Install minutes: ~5

### `foundation-05-skill-builder`

- Tier default: Pro / Max / Code
- Skills to paste: build-skill, validate-skill, list-my-skills
- Pack file: `packs/foundation-05-skill-builder.md`
- Install minutes: ~5

### `foundation-06-routing-rules`

- Tier default: Pro / Max / Code
- Skills to paste: route-deliverable, routing-audit, routing-suggest
- Pack file: `packs/foundation-06-routing-rules.md`
- Install minutes: ~12

### `foundation-07-memory-architecture`

- Tier default: Pro / Max / Code
- Skills to paste: capture-memory, recall-memory, memory-audit
- Pack file: `packs/foundation-07-memory-architecture.md`
- Install minutes: ~11

### `foundation-08-source-sweep`

- Tier default: Pro / Max / Code
- Skills to paste: source-sweep, stamp-sources, tier-down-sources
- Pack file: `packs/foundation-08-source-sweep.md`
- Install minutes: ~5

### `foundation-09-output-validator`

- Tier default: Code
- Skills to paste: output-validator, validate-output, self-check, pre-send-email-gate
- Pack file: `packs/foundation-09-output-validator.md`
- Install minutes: ~5

### `foundation-10-email-playbook`

- Tier default: Pro / Max / Code
- Skills to paste: classify-audience, draft-email, email-pre-send-gate, thread-summarize
- Pack file: `packs/foundation-10-email-playbook.md`
- Install minutes: ~6

### `foundation-11-notion-write-gate`

- Tier default: Pro / Max / Code
- Skills to paste: notion-write-with-verify, declare-expected-state, notion-state-diff, notion-auto-remediate
- Pack file: `packs/foundation-11-notion-write-gate.md`
- Install minutes: ~5

### `intro-00-tier-guide`

- Tier default: Pro / Max / Code
- Skills to paste: tier-detector, install-path-router, first-pack-recommender
- Pack file: `packs/intro-00-tier-guide.md`
- Install minutes: ~5

### `beg-01-chat-to-projects`

- Tier default: Pro
- Skills to paste: chat-to-projects, personal-cos, email-drafter, meeting-summarizer
- Pack file: `packs/beg-01-chat-to-projects.md`
- Install minutes: ~5

### `beg-02-desktop-organizer`

- Tier default: Pro
- Skills to paste: desktop-organizer, file-search, jobsite-photo-router
- Pack file: `packs/beg-02-desktop-organizer.md`
- Install minutes: ~17

### `beg-03-voice-to-task`

- Tier default: Pro
- Skills to paste: voice-to-task, task-search, daily-priority-roller
- Pack file: `packs/beg-03-voice-to-task.md`
- Install minutes: ~7

### `beg-04-first-skill-bootstrap`

- Tier default: Pro
- Skills to paste: first-custom-skill, skill-tester, skill-versioner
- Pack file: `packs/beg-04-first-skill-bootstrap.md`
- Install minutes: ~8

### `mid-01-email-playbook-tier-aware`

- Tier default: {{CLAUDE_TIER}}
- Skills to paste: email-playbook, email-classifier, email-followup-tracker
- Pack file: `packs/mid-01-email-playbook-tier-aware.md`
- Install minutes: ~9

### `mid-02-expense-automation`

- Tier default: {{CLAUDE_TIER}}
- Skills to paste: expense-automation, receipt-finder, gl-coder
- Pack file: `packs/mid-02-expense-automation.md`
- Install minutes: ~11

### `mid-03-daily-briefing`

- Tier default: {{CLAUDE_TIER}}
- Skills to paste: daily-briefing, evening-wrap-up, context-loader
- Pack file: `packs/mid-03-daily-briefing.md`
- Install minutes: ~10

### `mid-04-knowledge-search`

- Tier default: {{CLAUDE_TIER}}
- Skills to paste: knowledge-search, decision-recall, cross-source-search
- Pack file: `packs/mid-04-knowledge-search.md`
- Install minutes: ~8

### `adv-01-proposal-builder`

- Tier default: Pro / Max / Code
- Skills to paste: proposal-builder, gc-quirk-library, cover-letter-drafter
- Pack file: `packs/adv-01-proposal-builder.md`
- Install minutes: ~8

### `adv-02-meeting-to-tasks`

- Tier default: Pro / Max / Code
- Skills to paste: meeting-to-tasks, attendee-roster-resolver, notion-task-writer
- Pack file: `packs/adv-02-meeting-to-tasks.md`
- Install minutes: ~9

### `adv-03-contract-review`

- Tier default: Pro / Max / Code
- Skills to paste: contract-review, state-statute-flagger, redline-drafter
- Pack file: `packs/adv-03-contract-review.md`
- Install minutes: ~9

### `adv-04-skill-creator-meta`

- Tier default: Pro / Max / Code
- Skills to paste: skill-creator-meta, workflow-validator, voice-enforcer
- Pack file: `packs/adv-04-skill-creator-meta.md`
- Install minutes: ~8

### `pow-01-cold-start-protocol`

- Tier default: Code
- Skills to paste: cold-start-verify, identity-stamp, rules-enforcer
- Pack file: `packs/pow-01-cold-start-protocol.md`
- Install minutes: ~10

### `pow-02-rag-knowledge-search`

- Tier default: Code
- Skills to paste: knowledge-search, corpus-reindex, citation-formatter
- Pack file: `packs/pow-02-rag-knowledge-search.md`
- Install minutes: ~12

### `pow-04-multi-model-jury`

- Tier default: Code
- Skills to paste: multi-model-jury
- Pack file: `packs/pow-04-multi-model-jury.md`
- Install minutes: ~8

### `biz-01-notion-mcp-setup`

- Tier default: Pro / Max / Code
- Skills to paste: notion-mcp-bootstrap, notion-rollup-explain, notion-database-suggest
- Pack file: `packs/biz-01-notion-mcp-setup.md`
- Install minutes: ~8

### `biz-02-email-to-notion-intel`

- Tier default: Pro / Max / Code
- Skills to paste: email-classify, email-to-notion-write, synthesis-rollup, weekly-intelligence-brief
- Pack file: `packs/biz-02-email-to-notion-intel.md`
- Install minutes: ~10

### `biz-03-email-triage-responder`

- Tier default: Code
- Skills to paste: email-scan, email-triage-rank, email-draft, morning-email-routine
- Pack file: `packs/biz-03-email-triage-responder.md`
- Install minutes: ~6

### `biz-04-team-ai-enablement`

- Tier default: Code
- Skills to paste: rollout-projects, starter-skill-kit, skill-share, adoption-metrics
- Pack file: `packs/biz-04-team-ai-enablement.md`
- Install minutes: ~7

### `biz-05-document-prep-engine`

- Tier default: Pro / Max / Code
- Skills to paste: build-perennial-doc, doc-review-perennial-standard, kpi-card-builder, doc-bluf
- Pack file: `packs/biz-05-document-prep-engine.md`
- Install minutes: ~9

### `biz-06-proposal-heavy`

- Tier default: Pro / Max / Code
- Skills to paste: (skill body embedded inline)
- Pack file: `packs/biz-06-proposal-heavy.md`
- Install minutes: ~12

### `biz-07-proposal-light`

- Tier default: Pro / Max / Code
- Skills to paste: proposal-light, build-proposal-light, change-order-draft, pricing-quick, proposal-light-send
- Pack file: `packs/biz-07-proposal-light.md`
- Install minutes: ~7

### `biz-08-bd-ai-training`

- Tier default: Pro / Max / Code
- Skills to paste: bd-ai-training, load-bd-session, bd-homework-tracker, bd-skill-deploy, bd-progress-report
- Pack file: `packs/biz-08-bd-ai-training.md`
- Install minutes: ~9

## After install

Open a fresh chat in your Project. Paste the smoke test from `README.md` Section 4. Confirm every skill comes back named. Done.
