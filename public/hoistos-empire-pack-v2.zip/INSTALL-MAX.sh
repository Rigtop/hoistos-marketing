#!/usr/bin/env bash
# INSTALL-MAX.sh
# Max desktop tier install: opens hoistos.com so you can use the per-pack
# copy buttons and paste each pack into Claude desktop.
# If your machine does not have Claude desktop installed, fall back to the
# browser paste flow.
set -euo pipefail

URL="https://hoistos.com/empireworksreconstruction/timeline"
BUNDLE_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "HoistOS Empire Pack v2 - Max desktop install"
echo ""
echo "This installer opens the timeline page so you can use copy buttons"
echo "and paste each pack into your Claude desktop app."
echo ""
echo "Bundle location: $BUNDLE_DIR"
echo "Opening: $URL"
echo ""
if command -v open >/dev/null 2>&1; then
  open "$URL"
elif command -v xdg-open >/dev/null 2>&1; then
  xdg-open "$URL"
else
  echo "No open command found. Manually open: $URL"
fi
echo ""
echo "Fallback: if Claude desktop is unavailable, use INSTALL-PRO.md instead."
echo "It paste-installs each pack into Project Knowledge on claude.ai."
