#!/usr/bin/env bash
# INSTALL-MAX.sh
# Max desktop tier install: opens hoistos.com so you can use the per-pack
# claude:// deep links to install one pack at a time into your Claude desktop app.
# If your machine does not have the claude:// scheme registered (no Claude desktop
# app installed, or browser blocked it), fall back to the Pro paste flow.
set -euo pipefail

URL="https://hoistos.com/empireworksreconstruction/timeline"
BUNDLE_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "HoistOS Empire Pack v2 - Max desktop install"
echo ""
echo "This installer opens the timeline page so you can use the claude:// deep links"
echo "for one-click install into your Claude desktop app."
echo ""
echo "Bundle location: $BUNDLE_DIR"
echo "Opening: $URL"
echo ""
if command -v open >/dev/null 2>&1; then
  open "$URL"
elif command -v xdg-open >/dev/null 2>&1; then
  xdg-open "$URL"
else
  echo "No open command found. Manually open: $URL"
fi
echo ""
echo "Fallback: if claude:// does not register, use INSTALL-PRO.md instead."
echo "It paste-installs each pack into Project Knowledge on claude.ai."
