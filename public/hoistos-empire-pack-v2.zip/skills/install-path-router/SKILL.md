---
name: install-path-router
description: When the user is about to install a new pack and asks "where do I paste this" or "what do I do with this skill" or any equivalent, return the install path for THEIR tier (read from the Tier Guide block in Project Knowledge). Do not show all three paths; show only the one that applies. Use whenever the user pastes a pack body or a SKILL.md and asks for the install instruction.
version: 2.0.0
created: 2026-05-09
---

# Install Path Router

## When I fire

The user pastes a pack body or a SKILL.md and asks any of:
- "where do I paste this"
- "what do I do with this"
- "how do I install this"
- "where does this go"
- "is this Project Knowledge or a file"

## What I do

1. Read the user's tier from the `## Tier Guide` block in Project Knowledge.
2. Match the pack content to the right path on that tier:

| Tier | If pack body says "Artifact 1: Project Knowledge block" | If pack body says "SKILL.md for X" |
|---|---|---|
| Pro web | "Paste below your existing Project Knowledge content. Click Save." | "Paste BELOW the Project Knowledge block, as a section. Click Save. The skill activates on the next chat in this Project." |
| Max desktop | Same as Pro. (If a `claude://` deep-link is published for this pack on the catalog page, mention that as a faster alternative.) | Same as Pro. |
| Code CLI | "Save the body to `~/.claude/CLAUDE.md` (append, do not overwrite). Restart Claude Code session." | "Save to `~/.claude/skills/<name>/SKILL.md` where `<name>` matches the `name:` field in the SKILL.md frontmatter. Restart Claude Code session." |

3. Return ONE install path (the one that matches the user's tier). Do not show all three.

## What success looks like

One install instruction, specific to the user's tier, with the exact path or panel name. Confidence stamp: high.

## What failure looks like

Claude returns all three paths and asks the user to pick. The user's tier is already known; pick for them.

## Refusal scope

If the user asks me to install on a tier they are not on (e.g., "save this to `~/.claude/skills/`" but they are on Pro web), I flag the mismatch in one sentence: "You are on {{VP_TIER}}. The path `~/.claude/skills/` does not exist on your tier. Use the Project Knowledge paste path instead."
