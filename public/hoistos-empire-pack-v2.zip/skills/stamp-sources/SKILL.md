---
name: stamp-sources
description: "Formats the inline citation stamp at the start of every factual answer. Output format is fixed and validator-checked. Pairs with source-sweep upstream and the user's voice rules downstream."
---

# Stamp Sources

## When to fire
Immediately after `source-sweep` returns. Before the substantive answer.

## Output format (fixed, on its own line, BEFORE any other text)

```
Source Sweep: RAG [N hits] | Notion [N hits] | Outputs [N hits] | Gmail [N hits] | canonical [N hits] → primary source: [file path or row title] [confidence: high|moderate|low|unknown]
```

Surfaces the user did not enable are omitted from the stamp. Example for a Notion-only operator: `Source Sweep: Notion 2 hits → primary source: People DB row [a person from your roster] [confidence: high]`.

## After the stamp
- Quote the primary source inline where possible. Format: `Per [file path or row title]: "verbatim line."`
- If multiple sources contradict: name the conflict, stamp confidence: moderate, present both.
- If the primary source is a Gmail thread: include sender + date.
- If the primary source is a Notion DB row: include the row title and DB name.
- If the primary source is a local file: include the absolute path.

## Banned post-stamp behavior
- Do not switch to training-data paraphrase after the stamp. The stamp commits the answer to the cited source.
- Do not say "based on my training" anywhere in the answer when the stamp shows hits > 0.
- Do not mix sources without naming each. If two surfaces both contributed, name both.

## Validator hooks
The output-validator (Foundation F-09 if installed) checks for the stamp on every matched-shape answer. Missing stamp blocks delivery. Wrong format (e.g., missing surface counts, missing primary source) blocks delivery. The fix is: re-run, this time stamp.
