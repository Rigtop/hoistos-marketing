---
name: email-triage-rank
description: "Inbox triage ranker. Takes the actionable set from email-scan and ranks by urgency (HIGH / MEDIUM / LOW), then by stakes within urgency (deadline, sender authority, dollar amount, project tag), then by wait time. Returns a ranked dashboard table. Mandatory triggers: 'rank my email', 'triage', 'what's most urgent', or chained from email-scan inside morning-email-routine."
---

# Email Triage Rank

## Purpose
Order the inbox by stakes-not-volume. The HIGH items get drafted first because they move money, not because the user scrolled to them first.

## When to fire
- Chained from email-scan inside `morning-email-routine` as Step 2.
- User says: `rank my email`, `triage`, `what's most urgent`, `urgency`, `prioritize my inbox`.

## Steps

### Step 1: Apply urgency rules
For each thread in the actionable set:

| Tag if | HIGH |
|---|---|
| Subject mentions money (invoice, payment, AR, AP, balance, overdue) | yes |
| Sender is a GC PM or owner client and reply is overdue 2+ days | yes |
| Subject mentions compliance/legal (DOL, OSHA, NYCHA wage, certified payroll, Schedule A, AT-401) | yes |
| Subject mentions deadline within 24 hours | yes |
| Sender has a meeting with user today (`meeting_today` tag from email-scan) | yes |
| Project-tagged matching one of {{ACTIVE_PROJECTS}} AND wait > 24 hours | yes |

| Tag if | MEDIUM |
|---|---|
| Active project coordination | yes |
| Document request | yes |
| Team question | yes |
| Standard client response | yes |

| Tag if | LOW |
|---|---|
| FYI-type messages | yes |
| Non-urgent internal | yes |
| Vendor intros | yes |
| Newsletters slipped through | yes |
| Automated (rare, should be filtered already) | yes |

### Step 2: Within HIGH, rank by stakes
1. Dollar amount mentioned (highest first).
2. Deadline distance (closest first).
3. Sender authority (GC owner > GC PM > sub PM > sub foreman > other).
4. Wait time (longest first).

### Step 3: Within MEDIUM, rank by wait time + project tag
Project-tagged MEDIUM > untagged MEDIUM. Wait time descending within each.

### Step 4: Within LOW, rank by wait time only
Used for end-of-routine batch acks.

### Step 5: Emit the dashboard
Markdown table, ranked. Per BD Training Session 3 format:

| Urgency | From | Subject | Waiting | Tier | Suggested action |
|---|---|---|---|---|---|
| HIGH | your top client contact (your largest GC) | RE: your interior renovation project - schedule slip | 28h | gc_client | Reply: confirm slip cause + propose mitigation |
| HIGH | your GC contact (Related) | RE: Invoice #4521 | 3d | gc_client | Reply: confirm receipt, ask for timeline |
| HIGH | a GC PM (Turner) | your largest active project Scope Question | 26h | gc_client | Reply: answer scope, CC your principal |
| MEDIUM | a property-management contact (CBRE) | Meeting Follow-Up | 2d | gc_client | Reply: send one-pager, book walk |
| MEDIUM | a property-management contact (JLL) | RE: Property Walk Date | 6h | gc_client | Reply: confirm Thursday 2pm |
| LOW | Calendly | Meeting Confirmed | today | external | No reply needed |

### Step 6: Hand off
If chained from morning-email-routine, hand the ranked dashboard to email-draft for the top {{MORNING_ROUTINE_MODE}} drafts. If standalone, return the dashboard for user to pick.

## Anti-patterns
- Ranking by volume (most recent first). Volume is not the same as stakes.
- Auto-promoting all gc_client emails to HIGH. Triage requires the rules.
- Hiding LOW items entirely. The user sees all three tiers in the dashboard. Transparency.

## Audit
Append `{ "ts": ..., "skill": "email-triage-rank", "high": H, "medium": M, "low": L, "ranked_top_5": [...] }` to {{AUDIT_LOG_LOCATION}}.
