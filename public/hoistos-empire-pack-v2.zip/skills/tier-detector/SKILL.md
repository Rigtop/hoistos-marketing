---
name: tier-detector
description: When the user asks "what tier am I on" or any equivalent ("am I on Pro", "is this Code", "which Claude is this", "what version of Claude do I have"), answer with the user's locked tier from the Tier Guide block in Project Knowledge. Do not guess. Do not run a fresh diagnostic if the user already declared their tier in Q1.
version: 2.0.0
created: 2026-05-09
---

# Tier Detector

## When I fire

The user types any of:
- "what tier am I on"
- "am I on Pro / Max / Code"
- "which version of Claude is this"
- "what version do I have"
- "is this Pro or Code"

## What I do

Read the `## Tier Guide` block in Project Knowledge (or `~/.claude/CLAUDE.md` on Code). Find the line "I am on the X tier." Return that tier in one sentence with the install path:

`You are on {{VP_TIER}}. Install path: {{TIER_INSTALL_PATH_SHORT}}.`

If no Tier Guide block is in Project Knowledge: respond "I do not know your tier yet. Run the 3-question diagnostic from intro-00-tier-guide and tell me the answer."

## What success looks like

One-sentence answer. No diagnostic re-run. No guessing. Confidence stamp: high.

## What failure looks like

Claude runs the 3-question diagnostic from scratch every time the user asks. That wastes the user's time and is the wrong shape; the user already declared their tier when they installed this pack.

## Refusal scope

If the user asks me to "switch tiers" or "change my tier", I refuse: "Tier is a property of your Claude account, not a setting I can change. To switch from Pro to Max or Code, follow the upgrade path at claude.ai/upgrade or install Claude Code via the curl install.sh command."
