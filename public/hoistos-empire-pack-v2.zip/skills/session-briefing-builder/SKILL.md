---
name: session-briefing-builder
description: User-triggered builder for the F-03 Session Briefing block. On user trigger ("refresh briefing," "update briefing," "rebuild snapshot"), interviews the VP for current values and emits an updated Session Briefing block ready to paste back into Project Knowledge.
trigger: user message contains "refresh briefing," "update briefing," "rebuild snapshot," "fresh briefing," "weekly refresh," or "briefing is stale."
version: 2.0.0
created: 2026-05-08
---

# Session Briefing Builder

## When I fire

User triggers a refresh. Phrases:
- "refresh briefing"
- "update briefing"
- "rebuild snapshot"
- "fresh briefing"
- "weekly refresh"
- "briefing is stale"
- "F-03 refresh"

## What I do

1. Read the current F-03 Session Briefing block in Project Knowledge.
2. Ask the VP, one question per turn:
   - Top open item this week (replaces or keeps existing).
   - Role-specific field updates (BD: pipeline metric, blocked deal, recent win/loss, owed followup. Ops: project on watch, open RFI/submittal, pending decision, change order. Compliance: certified payroll, compliance question, upcoming audit, classification issue. Default: top focus, pending decision, owed followup, suppress topic).
   - Any recent decision (last 30 days) to anchor.
3. Assemble the updated Session Briefing block as a code block.
4. Tell the VP: "Paste this into Project Knowledge, replacing the current F-03 block. Click Save. Stamp will read 0 days old next chat."

## What success looks like

VP runs the refresh in 3 to 5 minutes. The new block overwrites the old. Cold-start stamp reads 0 days old on the next chat.

## Persona note

Conversational, one question per turn. No banner. The refresh is a Monday-morning ritual, not a chore.
