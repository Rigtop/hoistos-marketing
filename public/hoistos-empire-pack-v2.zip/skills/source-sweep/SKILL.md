---
name: source-sweep
description: "Pre-answer parallel sweep across the user's authored surfaces. Fires on factual / procedural / who-handles / what-did-we-decide / how-do-we questions. Returns hit counts per surface and the primary source. Pairs with stamp-sources and tier-down-sources."
---

# Source Sweep

## When to fire
- The user asks a question matching the trigger shapes from Project Knowledge.
- The question is about the user's people, projects, decisions, SOPs, contracts, or compliance, not about general knowledge.
- The question is non-trivial. Skip on yes/no replies, code-write tasks, math, sub-agent sessions, explicit "just answer" overrides.

## How to fire
Run the sweep as a parallel set of tool calls in a single message. Surfaces (only those the user enabled in Q4):

1. RAG: `mcp__<your-rag-mcp>__search_corpus` (or the user's configured RAG MCP server). Top 10, similarity threshold 0.35.
2. Notion: `mcp__claude_ai_Notion__notion-search` against the user's canonical DBs (People, Decisions, Projects, SOPs, Procedure Library).
3. Local files: Bash grep over the user's INDEX_ROOTS from F-02, e.g., `~/Desktop/Outputs/`, `~/Documents/Work/`.
4. Gmail: `mcp__claude_ai_Gmail__search_threads` weighted toward {{TOP_GCS}}, the user's frequent senders, and the project name in the question.
5. Canonical: only after 1-4 return thin. Raw PDFs, contract files, CBA OCR, regulator publications.

Run all five (or the subset the user enabled) in a single tool-call batch. Do not run sequentially. The point of the parallel scan is that the answer is in one of the surfaces and we do not know which one.

## What to return
A summary block with hit counts per surface and the top hit per surface. Pass to the `stamp-sources` skill to format the inline citation.

## Confidence math
- 3+ surfaces hit, top hit score > 0.7: confidence = high.
- 1-2 surfaces hit, top hit score 0.4-0.7: confidence = moderate.
- 1 surface hit, score < 0.4 OR only 1 partial keyword match: confidence = low.
- 0 hits across all enabled surfaces: confidence = unknown. Pass to `tier-down-sources` skill for the honest-fallback flow.

## Skip conditions
- The question is conversational ("hey", "thanks", "yes please").
- The user said "just answer" or "don't sweep, I have context."
- The question is a code-write task (Coding Standards covers that gate via the coding-context-disclosure discipline).
- The question can be answered from the immediate conversation history (the file is already pasted in this thread).

## What NOT to do
- Do not invent a citation. If the sweep returns no hits, hand off to `tier-down-sources` and admit the gap.
- Do not skip surfaces silently. Stamp every surface queried, even at 0 hits.
- Do not paraphrase from training data and label the answer "high confidence." That is the failure mode this skill exists to prevent.
