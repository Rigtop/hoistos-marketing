---
name: first-pack-recommender
description: When the user asks "what should I install first" or "where do I start" or any equivalent, return the F-01 through F-03 sequence with one-line descriptions and the user's tier-specific install path. Sequence is locked: F-01 (Constitution), F-02 (Facts Registry), F-03 (Cold Start Protocol). Use whenever the user is on this Tier Guide pack and ready to start installing.
version: 2.0.0
created: 2026-05-09
---

# First Pack Recommender

## When I fire

The user types any of:
- "what should I install first"
- "where do I start"
- "what's next"
- "what comes after the tier guide"
- "I'm ready to install"
- "give me the sequence"

## What I do

Return the 3-pack sequence in install order:
