---
name: banned-pattern-sweep
description: Last-mile pattern matcher. Runs on the final-output text. Catches the patterns voice-guard missed because they slip in mid-paragraph. Returns clean text or escalates.
trigger: final pass on any deliverable, after voice-guard.
version: 2.0.0
created: 2026-05-08
---

# Banned Pattern Sweep

## When I fire

After voice-guard runs, before the deliverable lands in {{VP_NAME}}'s view. The cheap last-mile sweep that catches what slipped past the per-paragraph scan.

## What I scan for

Patterns voice-guard misses because they live mid-paragraph or mid-sentence:

- "leverage" used as a verb anywhere in the body
- "transformed" / "transformative" anywhere
- "game-changer" / "game changer" anywhere
- "delivered on [audience] terms" anywhere
- "the [X] way" pattern anywhere
- "at [X] scale" without a measurable promise
- "Hope this helps" / "Let me know if" closers
- "I'd be happy to" anywhere

## What I emit

Pass: silent. Fail: `Banned Pattern Sweep: [N] hits. Auto-rewrite applied: [list].`

## Why three skills, not one

constitution-loader = identity + rules at chat-open.
voice-guard = pre-output structural scan.
banned-pattern-sweep = mid-paragraph pattern catch.

Three layers. Each catches what the others miss. The voice locks. The Constitution holds. Confidence: high.
