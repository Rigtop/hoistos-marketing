---
name: first-custom-skill
description: |
  Companion skill for HoistOS Empire Pack v2. Source pack: beg-04-first-skill-bootstrap.md.
  This file is a placeholder. The canonical body lives inside the pack file in this bundle
  at packs/beg-04-first-skill-bootstrap.md, in the skill artifact section. Copy that body here, or
  re-run bundle-build.sh after the source pack adds an `Artifact: ~/.claude/skills/first-custom-skill/SKILL.md`
  fenced block.
install_path: ~/.claude/skills/first-custom-skill/SKILL.md
source_pack: packs/beg-04-first-skill-bootstrap.md
version: 2.0.0
---

# first-custom-skill

Open `packs/beg-04-first-skill-bootstrap.md` and follow Step 2 (Save the SKILL.md files locally).
The pack body is the source of truth. This stub exists so the bundle's `skills/` tree
is browsable and the install script has a path to copy from.
