---
name: email-pre-send-gate
description: Refuses to render any email draft that contains a banned pattern. Runs after draft-email, before mcp__claude_ai_Gmail__create_draft is called. Hard-blocks on em dashes, lone-comma sign-offs, office address in signature, compound-name openers, find-attached openers without "Please see", missing default CC when not overridden, AI tropes, apology-for-delay phrases, and any phrase in {{BANNED_PHRASES}}. Also enforces the locked signature block exactly. Returns PASS with the draft body, or REFUSE with the specific rule violated and the offending text.
---

# Email Pre-Send Gate

## Purpose
The last line of defense. If a draft has any banned pattern, the gate refuses to render the Gmail draft. The VP never sees a violating draft. The skill that drafted has to fix and resubmit.

## Gate checks (run in order, all must pass)

### Check 1: em-dash scan
- Scan for U+2014 (em dash) and U+2013 (en dash) in subject, body, signature.
- If found: REFUSE. Reason: "Em dash detected at [line N]. Replace with comma, period, colon, or split sentence."

### Check 2: signature block lock
- Last 5 lines of body must match {{SIGNATURE_BLOCK}} exactly. No extra blank lines, no extra text below.
- No office address in any line of the signature.
- No email address in the signature (it is in the From field already).
- No long-form formal sign-off above the signature (no "Warm" closer, no "Sincerely" closer, no lone-comma sign-off).
- If signature does not match: REFUSE. Reason: "Signature block does not match locked 5 lines. Diff: [show diff]."

### Check 3: opener scan
- Scan first non-blank line of body.
- Banned: "Hi Mr. [LASTNAME],", "Hi Mrs. [LASTNAME],", "D[X]ear [LASTNAME],", any compound-name opener.
- If found: REFUSE. Reason: "Compound-name opener at line 1. Replace with first name or no name."

### Check 4: AI-trope scan
- Banned phrase list (always-on, regardless of {{BANNED_PHRASES}}). Each rendered with `[X]` mid-word in this docs file so the docs do not self-trigger:
  - "I h[X]ope this email finds you well"
  - "Please d[X]o not hesitate to reach out"
  - "As p[X]er our previous conversation"
  - "I w[X]anted to circle back"
  - "P[X]er my last email"
  - "B[X]est regards" (as a closer)
  - lone-comma sign-off (single closer word followed by comma alone)
  - "D[X]ear [name]"
  - "find-attached" opener (must be "Please see attached" or "Attached, [filename]")
  - "S[X]orry for the slow response"
  - "A[X]pologies for the delay"
- Implementation: gate matches the un-bracketed forms (production scanner strips the `[X]` placeholder). If any unbracketed form is found in a real draft: REFUSE. Reason: "AI trope detected: [phrase]. Replace with [VP-voice alternative]."

### Check 5: VP-specific banned phrases
- Scan body for any phrase in {{BANNED_PHRASES}}.
- If found: REFUSE. Reason: "VP-specific banned phrase detected: [phrase]. Replace or remove."

### Check 6: default CC enforcement
- Verify CC list contains every address in {{DEFAULT_CC}} unless:
  - One of them is in From (sender of incoming) -> drop is OK
  - One of them is in To -> drop is OK
  - VP explicitly said "just me" or "drop [Name]" -> drop is OK
- If a default CC is missing without an override reason: REFUSE. Reason: "Default CC [address] missing without override. Add to CC or override explicitly."

### Check 7: thread CC preservation (replies only)
- For replies: every recipient in the incoming message's To+CC must be on the reply (To or CC), unless explicitly overridden.
- If a thread participant is dropped without explicit override: REFUSE. Reason: "Thread participant [address] dropped without override. Restore or override explicitly."

### Check 8: subject-line em-dash scan
- Scan subject line for U+2014 and U+2013.
- If found: REFUSE. Reason: "Em dash in subject. Replace with colon or pipe."

### Check 9: Desktop mirror (post-pass enforcement)
- If draft body or htmlBody references a path under `~/Desktop/Outputs/`, copy that file to `~/Desktop/` for drag-attach convenience.
- Idempotent: skip if already at Desktop.
- This runs as a PostToolUse hook (`~/.claude/hooks/email-draft-desktop-mirror.sh`) on Code tier. On Pro/Max, surface the manual instruction.

## Construction VP gate scenarios

### Pass example: your top client contact schedule slip
- Body: "Hey your top client contact, Quick update on your interior renovation abatement..."
- Subject: "your interior renovation: Abatement schedule update"
- Signature: locked 5 lines
- CC: ceo@yourcompany.com, director-ops@yourcompany.com
- Result: PASS. Render Gmail draft.

### Refuse example 1: AI trope
- Body opens with the corporate-template "h[X]ope this email finds you well" line (un-bracketed in the actual draft).
- Result: REFUSE. Reason: "AI trope detected. Replace with 'Hope all is well' or remove the opener entirely."

### Refuse example 2: missing default CC
- Body: clean
- CC: only director-ops@yourcompany.com (your principal missing, no override stated)
- Result: REFUSE. Reason: "Default CC ceo@yourcompany.com missing without override. Add or override."

### Refuse example 3: em-dash in subject
- Subject: "your interior renovation abatement, schedule update"  (note: em dash, U+2014)
- Result: REFUSE. Reason: "Em dash in subject at position 22. Replace with colon or pipe."

### Refuse example 4: signature drift
- Last 5 lines: include "[YOUR-OFFICE-LINE]" (canonical-banned office phone, cell-only signature discipline)
- Result: REFUSE. Reason: "Signature block does not match locked 5 lines. Office phone [YOUR-OFFICE-LINE] is canonical-banned. Use [YOUR-CELL] only."

## Triggers
- Always called after draft-email, before mcp__claude_ai_Gmail__create_draft.
- On Code tier: also runs as PreToolUse hook at `~/.claude/hooks/email-playbook-pre-send.sh` (the email-playbook pre-send discipline).

## Pack provenance
- Pack: foundation-10-email-playbook v2.0.0
- Source: the canonical Email Playbook discipline + prior load-gate violations captured during voice playbook tuning
- Mirrored hook: `~/.claude/hooks/email-playbook-pre-send.sh` for Code tier enforcement
