---
name: adoption-metrics
description: "Weekly (or configured frequency) sweep of every report's Claude usage. Counts skill invocations per report, surfaces top wins, surfaces top friction. Outputs a one-screen dashboard for the VP to read on Monday morning. Mandatory triggers: 'adoption metrics', 'team usage', 'who is using ai', 'team report', 'how is the rollout going', 'check adoption'."
---

# Adoption Metrics

## Purpose
The VP knows, every week, who is using AI, where the wins are, where the friction is. Targeted support replaces blanket nudges.

## When to fire
- Cron-like schedule per {{METRICS_FREQUENCY}} (default: every Sunday 6 PM, output on Monday 8 AM).
- User says: `adoption metrics`, `team usage`, `who is using ai`, `team report`, `how is the rollout going`, `check adoption`.

## Steps

### Step 1: Pull invocation counts per report
For each report:
- Code tier: parse `~/.claude/logs/decisions-[report-slug].jsonl` and `~/.claude/logs/morning-email.jsonl` and any other audit logs initialized by the starter kit.
- Pro/Max tier: parse Project Knowledge `usage.jsonl` if the starter-skill-kit initialized it. (Pro/Max does not expose chat-level usage, so this is best-effort: count chat starts per Project.)
- Team plan: pull team-level analytics if available.

For each report, count:
- Total skill invocations this week.
- Unique skills used.
- Skills built or extended (this is the BIG metric: who is moving from consumer to builder).
- Decisions logged.

### Step 2: Surface top wins
A win is:
- A skill the report built (not pushed to them) that fired more than 3 times this week.
- A measurable outcome (`report drafted 30 emails this week with email-drafter, 0 manual rewrites`).
- A friction-ticket the report self-resolved by building a fix-skill.

Identify the top 3 wins of the week.

### Step 3: Surface top friction
A friction is:
- A skill that failed for a report (validator FAIL, gate hold, repeated errors).
- A friction-ticket open more than 3 days.
- A report whose invocation count is < 3 for the week (likely not adopted).

Identify the top 3 friction points.

### Step 4: Builder vs. consumer ratio
The asymmetry metric. Reports who built or extended a skill this week vs. reports who only consumed.

Target by week 4: at least 50% of reports are in the builder column.

### Step 5: Output the dashboard
One screen, 8 lines max. Per BD Training Session 3 dashboard standard, but for team adoption.

```
Team AI Adoption [week of date]
Reports active: 5/5 (your first BD, your second BD, your field lead, your HR or compliance lead, your compliance manager)
Total skill invocations: 142 (median 28 per report)
Builders this week: 3 (your HR or compliance lead built crew-headcount-by-project, your field lead extended daily-foreman-brief, your compliance manager built cba-citation-check)
Consumers only: 2 (your first BD, your second BD - watch for week 5)

Top 3 wins:
  1. your HR or compliance lead: crew-headcount-by-project fired 11 times, saved her 4 hours this week.
  2. your field lead: daily-foreman-brief now includes weather + crew + materials, ships in 90 seconds.
  3. your compliance manager: cba-citation-check caught 2 wrong DC9 trigger claims before send.

Top 3 friction:
  1. your first BD: email-drafter failing on cold outreach tier classification (5 retries).
  2. your second BD: daily-brief skipping calendar context (Google Calendar MCP intermittent).
  3. your field lead: friction-ticket #4 open 5 days (foreman skill needs site photo upload, blocked on MCP).

Recommendation: Pair your first BD + your HR or compliance lead for 30 min on email-drafter tier classifier. Resolve your second BD's Calendar MCP. your field lead's friction-ticket: bump to F-05 Skill Builder for site-photo workflow.
```

### Step 6: Hand off
- Output the dashboard to VP.
- Optional: draft a Slack message to the team with the top 3 wins (named, gratitude). Never auto-send. Draft only.
- Log the run.

## Anti-patterns
- Reporting only volume metrics (total invocations). The asymmetry metric (builders vs. consumers) is the real signal.
- Hiding friction. Surface every friction point. The VP cannot help with what they cannot see.
- Auto-sharing the dashboard with the team. The dashboard is for the VP. The Slack draft (Step 6) is opt-in.
- Running adoption-metrics in week 1. Too early; reports have not had time to build. First adoption-metrics run is end of week 2.

## Audit
Append `{ "ts": ..., "skill": "adoption-metrics", "week": "...", "reports_active": N, "total_invocations": N, "builders": [...], "consumers_only": [...], "top_wins": [...], "top_friction": [...] }` to {{AUDIT_LOG_LOCATION}}.
