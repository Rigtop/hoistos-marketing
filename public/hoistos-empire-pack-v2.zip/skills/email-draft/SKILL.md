---
name: email-draft
description: "Tier-aware email drafter. Reads a thread, identifies audience tier from {{AUDIENCE_TIERS}}, pulls matching voice fingerprint, drafts a reply in user's voice, runs F-09 pre-send-email-gate, creates Gmail draft via mcp__claude_ai_Gmail__create_draft, never auto-sends. Mandatory triggers: 'draft email', 'reply to', 'follow up with', 'write back', 'send a note', 'compose email', or chained from email-triage-rank inside morning-email-routine."
---

# Email Draft

## Purpose
Produce a Gmail draft that sounds like the user wrote it, at the right register for the right reader, validated before delivery.

## When to fire
- User says: `draft email`, `reply to`, `follow up with`, `write back to`, `send a note to`, `compose email`.
- Forwarded thread with no other instruction (auto-classify, draft reply).
- Chained from email-triage-rank inside `morning-email-routine`.

## Steps

### Step 1: Load Email Playbook (F-10)
Read `~/Desktop/AI Architecture/Claude Workspace/Global/Email Playbook.md` if present, OR the F-10 Project Knowledge block. Per the email-tier surface rules (HTML team default, plain-language instructional, plain-text compliance).

### Step 2: Gather context
- For a reply: read full thread via `gmail_read_thread`. Note the threadId.
- For a forward: read original message, identify recipient, decide silent vs. context forward (see F-10 Scenario 9).
- For a new compose: confirm recipient, subject, purpose. CC per {{DEFAULT_CC}}.

### Step 3: Identify audience tier
Classify the recipient into one of {{AUDIENCE_TIERS}}:
- Email domain (yourcompany.example = internal_team).
- Job title in signature (`Compliance Officer` = compliance, `Project Executive` = gc_client, `Foreman` = sub_vendor).
- Thread history (if user previously replied formally, stay formal).
- Top-recipients-per-tier mapping ({{TOP_RECIPIENTS_PER_TIER}}).
- Explicit override from user (`draft this to John as if he were a GC` = gc_client).

If classification is ambiguous, ASK: `Classifying [name] as [tier]. Confirm or override.`

### Step 4: Identify scenario (1 of 9 from F-10)
| # | Scenario | Key signal |
|---|---|---|
| 1 | Client Follow-Up | Client asked or sent something |
| 2 | Document Request | You need or are sending a doc |
| 3 | Collections | Money owed |
| 4 | Sales / BD | New business opportunity |
| 5 | Internal Team | your company team members |
| 6 | Compliance | Legal, incidents, government |
| 7 | Approvals | Routine sign-offs |
| 8 | HR / Personnel | Hiring, firing, benefits, policy |
| 9 | Forwarding | Routing to someone else |

### Step 5: Compliance Claim Pre-Draft Verification (the compliance-claim-verification discipline)
If thread or draft mentions: CBA, PLA, foreman trigger, apprentice ratio, Local 18/79/157, certified payroll, prevailing wage, Schedule A, AT-401, Section 3, Davis-Bacon (federal prevailing wage; your jurisdiction may differ), NYCHA wage, HUD wage, fringe fund, steward pay, MTDC, IUPAT, DC9, DCC, IBEW, Mason Tenders.

Then:
1. Enumerate every factual compliance claim the draft will make.
2. Verify each via `mcp__<your-namespace>-rag__search_corpus` (or your configured RAG MCP server), `Read` of the source CBA / PLA, OR `mcp__claude_ai_Notion__notion-fetch` of the authoritative page.
3. Cite article/section or file path inline (`Per DCC Independent Building CBA Art V Sec 3, GF triggers at 5+ Foremen.`).
4. If unverifiable: replace statement with question, mark `[UNVERIFIED]`, or remove.
5. Banned in compliance-adjacent: `typically triggers at X`, `I believe`, `if I recall`, `from memory`.

### Step 6: Draft (apply F-10 voice fingerprint for tier)

**Opener (per F-10 greeting tier table):**
- `Hey [first name],` for 80% of emails (people you have met or emailed).
- `Hi [first name],` for semi-formal first interactions with admin contacts.
- `[First name],` for urgent, compliance, or firm-tone-needed messages.
- `Hello [first name],` for new external contacts, formal complaints, first-touch sales.

**Body:**
- Match the scenario structure from F-10.
- Match or soften the incoming tone by one tier.
- Use user's actual phrases from voice fingerprint (`Received.`, `I'll circle back Friday.`, `This is right in our wheelhouse.`).
- Length: under 5 sentences for routine, under 10 for complex.

**Closer:**
- Sign-off matched to tier from {{DEFAULT_SIGNOFF}}.
- Signature block from {{VP_SIG_BLOCK}}.

### Step 7: Run F-09 pre-send-email-gate
Hand the draft to the validator. Pre-send-email-gate runs:
- F1-EMDASH: zero em-dashes / en-dashes in narrative.
- F-EMAIL-TIER: tone matches identified tier.
- F-EMAIL-NAME: recipient name matches people list / thread history.
- F-EMAIL-SIG: signature contains canonical block + cell phone (not any office line) + correct sign-off (not `Best,` alone).
- F-EMAIL-SEND: tool call is `mcp__claude_ai_Gmail__create_draft`, NEVER `send`.
- F2-IDENTITY: COO not CEO, your company full form, "90+ employees" if claim made.
- F5-BANNED: no phrases from {{CUSTOM_BANNED_PHRASES}} or F-01 banned list.

If any FAIL, auto-remediate up to 2 attempts, re-run gate, only present after PASS.

### Step 8: Create the Gmail draft
Call `mcp__claude_ai_Gmail__create_draft` with the threadId (for replies), recipient, subject, body, CC per {{DEFAULT_CC}}, and signature block.

PostToolUse hook (`email-draft-desktop-mirror.sh`) auto-mirrors any referenced PDF/docx attachment to `~/Desktop/` for drag-attach (per the desktop-mirror discipline).

### Step 9: Output to user
```
Draft saved. Tier: gc_client. Length: 7 sentences. Validator: 7/7 PASS.
Review at [Gmail drafts URL]. Reply 'send' to send, 'edit' to revise, 'next' for the next draft in queue.
```

NEVER auto-send. NEVER batch-send. Drafts only.

## Anti-patterns
- Drafting before identifying the tier. Always classify first.
- Pasting boilerplate from the playbook without adapting to thread context. Read the thread.
- Treating compliance-adjacent emails as standard. Run Step 5 even if uncertain.
- Sending. Ever. The validator F-EMAIL-SEND check blocks it.

## Audit
Append `{ "ts": ..., "skill": "email-draft", "tier": "...", "scenario": N, "thread_id": "...", "validator_pass": true, "draft_id": "..." }` to {{AUDIT_LOG_LOCATION}}.
