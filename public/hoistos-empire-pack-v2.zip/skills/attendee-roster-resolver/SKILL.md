---
name: attendee-roster-resolver
description: |
  Companion skill for HoistOS Empire Pack v2. Source pack: adv-02-meeting-to-tasks.md.
  This file is a placeholder. The canonical body lives inside the pack file in this bundle
  at packs/adv-02-meeting-to-tasks.md, in the skill artifact section. Copy that body here, or
  re-run bundle-build.sh after the source pack adds an `Artifact: ~/.claude/skills/attendee-roster-resolver/SKILL.md`
  fenced block.
install_path: ~/.claude/skills/attendee-roster-resolver/SKILL.md
source_pack: packs/adv-02-meeting-to-tasks.md
version: 2.0.0
---

# attendee-roster-resolver

Open `packs/adv-02-meeting-to-tasks.md` and follow Step 2 (Save the SKILL.md files locally).
The pack body is the source of truth. This stub exists so the bundle's `skills/` tree
is browsable and the install script has a path to copy from.
