---
name: cold-start-verify
description: Mandatory first-response gate. On any new chat in this Project, runs the 4-step boot sequence (Constitution, Facts Registry, Session Briefing, stamp). Blocks the substantive answer until the stamp lands.
trigger: any new chat in this Project, first non-trivial user message.
version: 2.0.0
created: 2026-05-08
---

# Cold Start Verify

## When I fire

First non-trivial user message in any chat inside this Project. Trivial: yes/no, one-word replies, file confirmations. Everything else fires the gate.

## What I do (in order, every time)

1. Read F-01 Operating Constitution. Confirm voice rules + identity locks loaded.
2. Read F-02 Facts Registry. Confirm canonical facts + active context loaded.
3. Read F-03 Session Briefing. Confirm weekly snapshot + open items + recent decision loaded.
4. Compute days-since-refresh from F-03's `Generated on` date or last-edit timestamp.
5. Emit the stamp on line 1, on its own line: `COLD-START: F-01 voice ✓ | F-02 facts ✓ | F-03 briefing ({{REFRESH_DAY}} refresh, {{N}} days old) ✓`.
6. Answer the user's actual message.

## What success looks like

Stamp on line 1. The substantive answer respects all three blocks. Voice from F-01. Facts from F-02. Open-items context from F-03. Briefing freshness visible.

## Failure modes (and recoveries)

| Failure | Symptom | Recovery |
|---|---|---|
| Block did not save | Stamp says "F-01 not loaded" or "F-02 not loaded" | Re-paste the missing block in Project Knowledge |
| Stamp absent entirely | Reply opens with the substantive answer, no stamp | Skill did not register on Code, or Project Knowledge cleared on Pro. Re-install F-03 |
| Briefing > 7 days stale | Stamp shows "12 days old" on a Tuesday | Refresh ritual is overdue. Update F-03 fields, save |
| Wrong stamp format | Stamp omits ✓ or has extra fields | Re-paste cold-start-verify SKILL.md, frontmatter check |

## Persona note

I am the gate. I do not skip. I do not abbreviate. The stamp is the receipt; the receipt is how the VP knows the system is working.
