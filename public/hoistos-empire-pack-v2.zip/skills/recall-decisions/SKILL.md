---
name: recall-decisions
description: Search the Decision Log for {{VP_NAME}}. Triggers on phrases like "what did I decide about", "recall decisions", "what was my call on", "pull the log on", "decisions about". Use whenever the user is asking about a past decision, even if they do not say "log". Search the "## Decision Log entries" section of Project Knowledge, return matching entries verbatim with date and reason code.
version: 2.0.0
created: 2026-05-08
---

# recall-decisions

## Mission

When {{VP_NAME}} asks about a past decision ("what did I decide about your prevailing-wage project pricing", "recall decisions about your field lead", "what was my call on an affordable-housing owner change order"), search the "## Decision Log entries" section of Project Knowledge.

Return matching entries in this format ({{VP_RECALL_FORMAT}} default):

| Date | Reason | Summary | Tags |
|---|---|---|---|
| YYYY-MM-DD | DECISION | one-line summary | project, type |

If {{VP_RECALL_FORMAT}} is "bullet list", return as bullets. If "paragraph", return as a one-paragraph synthesis with dates inline. If "quoted-verbatim", return each matching entry as a code block, exactly as written.

## Search rules

- Match on tags first (project name, GC name, decision type)
- Then match on summary keywords
- Then match on full-text body
- Return at most 10 entries. If more than 10 match, sort by date descending and note "showing 10 of N"
- If zero entries match, say "no decisions logged on that topic. Want to log one now?"

## Voice rules

Inherited from Foundation 01. No em dashes. "your company" in full.

## Construction-VP examples

Example 1:
Input: "what did I decide about your prevailing-wage project pricing last month?"
Search target: tags contain "your prevailing-wage project" AND ("margin" OR "pricing"), date within 60 days
Output: table of matching entries with date, reason, summary, tags.

Example 2:
Input: "recall decisions about your field lead"
Search target: tags contain "your field lead" OR summary contains "your field lead"
Output: table of matching entries.

Example 3:
Input: "what was my call on an affordable-housing owner change order on Floor 7?"
Search target: tags contain "an affordable-housing owner" AND ("change order" OR "Floor 7")
Output: table or one quoted-verbatim entry if exact match.

## Pack provenance

Generated from: foundation-04-decision-log v2.0.0
Fingerprint: [SHA256 placeholder]
