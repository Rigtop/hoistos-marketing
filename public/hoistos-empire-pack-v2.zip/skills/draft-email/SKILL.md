---
name: draft-email
description: Drafts emails in {{VP_NAME}}'s voice using the audience tier matrix. Calls classify-audience first to pick the tier, pulls the matching voice fingerprint, drafts in 3 to 8 sentences (varies by tier), applies the banned-phrase filter, applies the em-dash filter, signs off with {{DEFAULT_SIGNOFF}}, appends the locked signature block, and outputs as a Gmail draft via mcp__claude_ai_Gmail__create_draft. NEVER auto-sends. Triggers on "draft email", "reply to", "follow up with", "write back", "send a note", "compose email", "shoot them an email", any forwarded thread with no other instruction, and any of the shortcut phrases in {{SHORTCUT_PHRASES}}.
---

# Draft Email

## Purpose
Runs the audience tier matrix to produce a tier-correct draft in {{VP_NAME}}'s voice, ready for the pre-send gate.

## Drafting protocol (in order)

1. Read the trigger context (forwarded thread, request, two-word shortcut, or "follow up with X about Y").
2. If a shortcut phrase from {{SHORTCUT_PHRASES}} matches, route to the canonical email shape for that shortcut. Otherwise continue.
3. Call classify-audience to identify the recipient tier. Honor confidence floors.
4. Pull the matching voice fingerprint row from the audience tier matrix in Project Knowledge.
5. Draft sentences using the tier's opener, length, formality, and signature-phrase set:
   - internal_team: "Hey [first name]," or "Hey guys,". 1 sentence to long-form. Signature phrases: "Quick update.", "Thanks team.", "Tell me what's missing."
   - sub_vendor: "Hey [first name]," or "[First name],". 3-5 sentences. "Hope all is well." opener acceptable. Close with "Appreciate it" + signature.
   - gc_client: "Hey [first name]," (familiar) or "[First name]," (formal). 2-5 sentences. Signature phrases: "Received.", "We will...", "I'll circle back Friday."
   - compliance: "[First name]," (no Hey). 1-3 paragraphs. Plain text on compliance threads. Sentence-case headers when multi-section ("Where we agree", "What seems wrong", "Path forward"). Verbatim CBA quotes preserved with "(verbatim)" disclosure.
   - govt_agency: "[First name]," or "Hello [first name],". 1-2 paragraphs. Formal-professional. Reference specific filings/numbers/dates.
   - legal_counsel: "Hey [first name]," (established) or "[First name]," (formal). Vary by relationship. Reference specific clauses, contracts, or dispute history.
   - external_client (sales/BD): "Hey [first name]," or "Hello [first name],". 4-6 sentences. Warm, collaborative. Signature phrases: "Would love to hop on a call", "This is right in our wheelhouse".
6. Apply banned-phrases filter. Strip any phrase from {{BANNED_PHRASES}}. Replace with neutral alternative or remove entirely.
7. Apply em-dash filter. Replace U+2014 and U+2013 with commas, periods, colons, or split sentences.
8. Apply compound-opener filter. No "Hi Mr. Smith,". Use first name or no name.
9. Apply find-attached filter. Replace any "find-attached" opener with "Please see attached" or "Attached, [filename]".
10. Sign off with the variant from {{VARIANT_SIGNOFFS}} matched to the tier (if VP supplied multiple).
11. Append the locked signature block from {{SIGNATURE_BLOCK}}. Exact 5 lines, no edits, no extra blank line at the bottom.
12. Set the Gmail thread CC: preserve every To+CC from the incoming message, add {{DEFAULT_CC}} if not already present, drop overrides per Project Knowledge override rules.
13. Hand the draft to the email-pre-send-gate skill. If the gate refuses, surface the refusal reason and offer to revise. If the gate passes, output as a Gmail draft via mcp__claude_ai_Gmail__create_draft. NEVER auto-send.
14. After draft creation, output: "Draft saved. Review at [Gmail drafts URL]. Reply 'send' to send, 'edit' to revise."
15. Mirror the deliverable to ~/Desktop/ if the email references an Outputs/ file (per the pack's auto-memory entry on email-playbook load discipline).

## Construction VP scenarios

### Scenario A: "draft a follow-up to your top client contact on your interior renovation abatement schedule slip"
- classify-audience: the GC project executive on your prevailing-wage project at major-gc.example -> gc_client, 0.95
- voice fingerprint: gc_client, "Hey [first name],", 2-5 sentences, formality 6
- shortcut match: "schedule slip"
- draft:
