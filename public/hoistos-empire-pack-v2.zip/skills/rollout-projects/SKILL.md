---
name: rollout-projects
description: "Provisions a Claude Project for each direct report. Loads role context, ships the starter Skill kit, broadcasts VP-level skills, books the 30-minute onboarding 1-on-1 via Google Calendar. Mandatory triggers: 'rollout my team', 'provision projects', 'set up reports', 'team rollout', 'enable my team', 'onboard my team to claude'."
---

# Rollout Projects

## Purpose
Stand up a Claude Project per direct report in one pass. The reports walk into a preconfigured environment, not an empty chat box.

## When to fire
- User says: `rollout my team`, `provision projects`, `set up reports`, `team rollout`, `enable my team`, `onboard my team to claude`.
- Chained from BIZ-04 install Step 4.

## Steps

### Step 1: Pre-flight
- Confirm {{REPORTS_LIST}} is populated.
- Confirm {{TIER_POSTURE}} is set.
- Confirm Google Calendar MCP is live (for onboarding 1-on-1 booking).
- Note start_ts.

### Step 2: For each report, provision a Project
For each report in {{REPORTS_LIST}}:

1. Create a claude.ai Project named `[Report Name] AI Operator`.
   - On Team plan: create in shared workspace.
   - On individual plan: create in VP's account, share access link to report.

2. Populate Project Instructions with:
   - VP-level Constitution (F-01).
   - Report-specific Facts Registry: name, email, role, division, top 3 active projects (from {{REPORTS_LIST}}).
   - Starter Skill kit list per {{STARTER_KIT_PER_REPORT}} for this report.
   - Voice inheritance mode per {{VOICE_INHERIT_MODE}}.

3. Tag the Project with the report's role and division for {{TIER_POSTURE}}-aware skill broadcast.

4. Output the Project URL or shared link.

### Step 3: Book the onboarding 1-on-1
Per {{ONBOARDING_CADENCE}}:
- One afternoon: book all reports back-to-back in 30-minute slots starting today + 2 days.
- Spread across a week: one report per day, 30-min slot, starting tomorrow.
- Two cohorts: top 3 today + 2 days, remaining 3 in 2 weeks.
- Async: send Calendly link.

Use `mcp__claude_ai_Google_Calendar__create_event` to book. Title: `[Report Name] AI Onboarding (30 min)`. Description: link to their Project + the BIZ-04 starter kit URL.

### Step 4: Broadcast VP skills
For each report, ship {{VP_SKILLS_TO_BROADCAST}} to their Project Knowledge.

### Step 5: Send the welcome note
For each report, draft a 4-sentence email (via email-draft skill, never auto-send) saying: `[Report Name], I set you up with a Claude Project tailored to your role. The link is [URL]. We have a 30-min walkthrough booked for [date/time]. Open the Project before then and run "summarize my role" to see what loaded. Questions, ping me. - [VP first name]`.

### Step 6: Output the rollout summary
```
Rollout: 5 reports.
Projects provisioned: 5 ([URL list])
Onboarding 1-on-1s booked: 5 (Tuesday 2pm, 2:30, 3:00, 3:30, 4:00 per {{ONBOARDING_CADENCE}})
Welcome notes drafted: 5 (in Gmail Drafts, ready to review and send)
VP skills broadcast: {{VP_SKILLS_TO_BROADCAST}} to all 5 Projects
Total time: 47 minutes
```

## Anti-patterns
- Auto-sending the welcome note. Never. Drafts only.
- Provisioning a generic Project. Each report's Project must have their role context, not a template.
- Skipping the calendar booking. Without the 1-on-1, half the reports never open the Project.
- Broadcasting skills the report's role does not need. Match {{STARTER_KIT_PER_REPORT}}.

## Audit
Append `{ "ts": ..., "skill": "rollout-projects", "reports_provisioned": N, "calendar_events": N, "skills_broadcast": [...], "duration_seconds": T }` to {{AUDIT_LOG_LOCATION}}.
