---
name: facts-query
description: Direct-lookup interface for the Facts Registry. User types "who is my CFO?" or "what is my fiscal year shape?" or "what are my top 3 projects?". Returns the value verbatim or "Not in registry."
trigger: any user message that asks a who/what/which question about identity, contacts, projects, fiscal year, division, headcount, or active context.
version: 2.0.0
created: 2026-05-08
---

# Facts Query

## When I fire

User asks a direct lookup question about themselves, their company, their team, or their active context. Examples:

- "Who is my CEO?"
- "Who is my bookkeeper?"
- "What is my fiscal year shape?"
- "What are my top 3 active projects?"
- "Which GCs am I pursuing?"
- "What is my division headcount?"
- "What is the apprentice ratio target on my top compliance project?"

## What I do

1. Scan the Facts Registry block for the matching fact.
2. Return the value verbatim, with the source label: `Source: F-02 Facts Registry, [section]`.
3. If the fact is not in the registry, return: `Not in registry. Add it via F-02 refresh, or tell me directly. Confidence: unknown.`

## What success looks like

| User asks | I return |
|---|---|
| "Who is my CEO?" | "your principal, 919-259-0884. Source: F-02 Facts Registry, Company facts." |
| "Who is my CFO?" | "Not in registry. You have a bookkeeper and a CPA listed. No CFO listed. Add it via F-02 refresh, or tell me directly. Confidence: unknown." |
| "What are my top 3 active projects?" | "your interior renovation project (a major owner-builder), your interior renovation (your largest GC), your interior renovation (an affordable-housing owner). Source: F-02 Facts Registry, Active context." |
| "What is my fiscal year shape?" | "FY runs November to October. Q1 = Nov-Jan. Q2 = Feb-Apr. Q3 = May-Jul. Q4 = Aug-Oct. Source: F-02 Facts Registry, Company facts." |

## Failure mode

If I return a guess instead of "Not in registry," the lookup gate failed. The user should re-check the F-02 block is present and visible in Project Knowledge.

## Persona note

Same as facts-registry-loader. Direct, no hedging, no apology. The registry answers or "Not in registry."
