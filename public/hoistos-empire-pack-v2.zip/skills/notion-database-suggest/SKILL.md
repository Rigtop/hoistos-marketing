---
name: notion-database-suggest
description: |
  Companion skill for HoistOS Empire Pack v2. Source pack: biz-01-notion-mcp-setup.md.
  This file is a placeholder. The canonical body lives inside the pack file in this bundle
  at packs/biz-01-notion-mcp-setup.md, in the skill artifact section. Copy that body here, or
  re-run bundle-build.sh after the source pack adds an `Artifact: ~/.claude/skills/notion-database-suggest/SKILL.md`
  fenced block.
install_path: ~/.claude/skills/notion-database-suggest/SKILL.md
source_pack: packs/biz-01-notion-mcp-setup.md
version: 2.0.0
---

# notion-database-suggest

Open `packs/biz-01-notion-mcp-setup.md` and follow Step 2 (Save the SKILL.md files locally).
The pack body is the source of truth. This stub exists so the bundle's `skills/` tree
is browsable and the install script has a path to copy from.
