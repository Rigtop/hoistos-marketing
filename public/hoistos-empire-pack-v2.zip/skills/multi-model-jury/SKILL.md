---
name: multi-model-jury
description: |
  Companion skill for HoistOS Empire Pack v2. Source pack: pow-04-multi-model-jury.md.
  This file is a placeholder. The canonical body lives inside the pack file in this bundle
  at packs/pow-04-multi-model-jury.md, in the skill artifact section. Copy that body here, or
  re-run bundle-build.sh after the source pack adds an `Artifact: ~/.claude/skills/multi-model-jury/SKILL.md`
  fenced block.
install_path: ~/.claude/skills/multi-model-jury/SKILL.md
source_pack: packs/pow-04-multi-model-jury.md
version: 2.0.0
---

# multi-model-jury

Open `packs/pow-04-multi-model-jury.md` and follow Step 2 (Save the SKILL.md files locally).
The pack body is the source of truth. This stub exists so the bundle's `skills/` tree
is browsable and the install script has a path to copy from.
