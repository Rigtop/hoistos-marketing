---
name: pre-send-email-gate
description: "Stricter pre-send gate specifically for email drafts. Runs ALL 9 checks from validate-output, plus 4 email-specific checks: tier-aware tone, recipient-name verified against people list AND Gmail thread history, signature-block validity, no auto-send. Mode: {{EMAIL_GATE_MODE}}. Triggers: any Gmail draft creation (`mcp__claude_ai_Gmail__create_draft`), 'email your top client contact', 'reply to', 'shoot them a note', 'follow up with', 'draft email', 'compose email'."
---

# Pre-Send Email Gate

## Purpose
Email is the highest-blast-radius surface in a construction VP's day. A typo in an internal Slack note is recoverable. A typo in an email to your top client contact at your largest GC is visible to the GC and possibly forwarded internally. Email gets the strictest gate.

## When to fire
- Mode `{{EMAIL_GATE_MODE}}`:
  - **every email:** fires on every Gmail draft.
  - **high-stakes only:** fires on drafts to clients, GCs, regulators, attorneys. Skips internal team domain.
  - **off:** does not fire (validate-output still runs as the general gate).
- Tool call detection: `mcp__claude_ai_Gmail__create_draft` is the trigger.

## Steps

### Step 1: Run validate-output (9 checks)
- All 9 checks from validate-output run first.
- Any FAIL triggers auto-remediation (max 2 attempts) before email-specific checks.

### Step 2: Tier-aware tone (Email Playbook)
- Classify the recipient tier:
  - Tier 1: client / GC executive (use formal-but-direct tone, no compound openers, no `Best,` sign-off, no `Attached is...`)
  - Tier 2: GC project executive / sub principal (formal, can be slightly warmer)
  - Tier 3: internal team (warmer, can use first-name openers)
  - Tier 4: compliance / legal / regulator (most formal, plain text on compliance threads)
- FAIL if the draft tone does not match the tier.
- On FAIL: rewrite to tier-correct tone, re-run.

### Step 3: Recipient name verification
- Cross-check `To:` and `Cc:` recipient names against `{{PEOPLE_LIST}}`.
- Cross-check against the Gmail thread history if a previous thread exists with that recipient (use thread-id from the draft context).
- FAIL if name does not match either source, OR the spelling differs from canonical (one-letter typos, voice-to-text substitutions, soundalikes).
- On FAIL: replace with canonical spelling. Re-run.

### Step 4: Signature block validity
- Required signature for the user:
```
{{VP_NAME}}
{{VP_ROLE}}
Your Company LLC
[cell phone]
```
- FAIL if signature contains any office line phone number (cell-only signature discipline).
- FAIL if signature renders the company as the two-letter abbreviation.
- FAIL if signature uses `Best,` or `Best regards,` (use `Thanks,` or no-sign-off-just-name per playbook).
- On FAIL: replace with the canonical signature, re-run.

### Step 5: No auto-send
- Hard rule: NEVER invoke email-send. Always create draft. Wait for explicit user `send` command.
- If the tool call is `send_email` instead of `create_draft`, REFUSE and re-route to `create_draft`.

### Step 6: Audit log
- Append to `{{AUDIT_LOG_LOCATION}}`:
```json
{ "ts": "ISO_TIME", "type": "email_gate", "to": "[recipient]", "tier": "[tier]", "checks_passed": N, "remediations": M }
```

### After all checks PASS
- Emit one-line audit: `Email gate: 13/13 PASS [+ "fixed [X], [Y] on draft v1, presenting v2." if any auto-remediated].`
- Present the draft to the user. NEVER auto-send.

## Authority
The email-playbook pre-send discipline. HTML formatting on internal team emails. Plain-language instructional emails. Plain-text compliance threads. Cell-only signature, no office line. Foundation 09 pack v2.0.0.
