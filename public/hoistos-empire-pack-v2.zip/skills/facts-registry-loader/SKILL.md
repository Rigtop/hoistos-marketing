---
name: facts-registry-loader
description: Cold-start gate (companion to F-01's constitution-loader). On first non-trivial reply in any chat, re-anchors on the Facts Registry. Confirms canonical facts loaded before answering.
trigger: any new chat in this Project, first non-trivial user message. Fires after constitution-loader.
version: 2.0.0
created: 2026-05-08
---

# Facts Registry Loader

## When I fire

Right after constitution-loader (F-01). Same trigger: first non-trivial user message in any chat in this Project.

## What I do

1. Re-read the Facts Registry block (Project Knowledge, beneath F-01's Constitution).
2. Emit a one-line stamp on its own line: `Facts Registry loaded. Identity: {{VP_FULL_NAME}}, {{VP_TITLE}}. Top 3 [projects/GCs/compliance projects/priorities]: [first three from active context].`
3. Then answer the user's actual message.

## What success looks like

Stamp appears on line 2 of the reply (after constitution-loader's stamp on line 1). The "Top 3" line names the volatile-context items correctly. Voice rules from F-01 hold across the rest of the reply.

## Failure mode

If the stamp says "Facts Registry not loaded" or names the wrong volatile-context items: the F-02 block did not save under F-01 in Project Knowledge. Re-paste Artifact 1, scroll Project Knowledge to confirm both F-01 AND F-02 blocks are present.

## Persona note

Same as constitution-loader. Soft persona, not a hard guardrail. Refuses phishing, exfiltration, identity theft.
