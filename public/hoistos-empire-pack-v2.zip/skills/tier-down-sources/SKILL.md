---
name: tier-down-sources
description: "Honest-fallback flow when the source sweep returns 0 hits. Default behavior is admit the gap, label the answer 'training fallback', stamp low confidence, and offer to ingest a file. Strict mode refuses outright."
---

# Tier Down Sources

## When to fire
- `source-sweep` returned 0 hits across all enabled surfaces.
- OR the top hit is below the user's similarity floor (default 0.35).
- OR all hits are stale (last_modified > 6 months ago) and the question is time-sensitive.

## Honest-fallback flow (default)

Output exactly this format:

```
Source Sweep: 0 hits across your sources, falling back to training. Confidence: low. The corpus does not contain this answer.
```

Then attempt the answer using training data. Stamp every claim with `confidence: low` inline. Offer two follow-ups at the end:

1. "Want me to read a specific file? Paste a path or link."
2. "Want me to flag this so you can author the SOP / decision / record? I will draft the entry for {{NOTION_DB or local folder}}."

## Strict-mode flow

If `{{CONFIDENCE_FLOOR}} = strict`:

Output exactly this format:

```
Source Sweep: 0 hits across your sources. Strict mode. Refusing training-data answer.
```

Then offer:

1. "Point me at a file or thread that holds this answer."
2. "Tell me the answer, and I will write it to {{NOTION_DB}} as a {{record_type}} so we have it next time."

Do NOT answer from training data in strict mode. The whole point of strict is the floor.

## Loose-mode flow

If `{{CONFIDENCE_FLOOR}} = loose`:

Stamp the sweep result and answer normally with confidence: low or unknown. No follow-ups required.

## Why honest fallback is the killer feature
The user has been talked down to by AI assistants their entire experience. Every wrong answer was delivered with the same confidence as every right answer. The first time this skill says "I do not have this", the user notices. That is the moment the assistant becomes trustable. Everything after is built on it.

## Banned behavior
- Do not invent a source name to fill the slot.
- Do not answer with training data and stamp confidence: high.
- Do not say "I think" or "I believe" without the explicit fallback line. The fallback line is the contract.
