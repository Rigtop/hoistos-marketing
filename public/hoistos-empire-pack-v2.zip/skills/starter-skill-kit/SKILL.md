---
name: starter-skill-kit
description: "Pushes the four baseline skills (email-drafter, daily-brief, decision-logger, F-05 Skill Builder) plus role-conditional add-ons to each report's Claude Project. Ensures every report walks into an AI-ready environment on day 1. Mandatory triggers: 'ship starter kit', 'push skills to reports', 'starter kit', 'enable starter skills'."
---

# Starter Skill Kit

## Purpose
Every report's Project loads with a working set of skills on day 1. No empty Project. No `where do I start` paralysis.

## When to fire
- User says: `ship starter kit`, `push skills to reports`, `starter kit`, `enable starter skills`.
- Chained from rollout-projects after Project provisioning.

## Steps

### Step 1: Confirm the four baselines are ready
- email-drafter SKILL.md
- daily-brief SKILL.md
- decision-logger SKILL.md
- F-05 Skill Builder SKILL.md (full, with build-your-own-skill onboarding tutorial)

If any are missing from {{VP_SKILLS_TO_BROADCAST}}, halt and prompt VP.

### Step 2: For each report, ship the kit
- Push the four baseline skills to their Project Knowledge or `~/.claude/skills/` based on tier.
- Apply {{STARTER_KIT_PER_REPORT}} role-conditional adds.
- For voice inheritance, configure email-drafter per {{VOICE_INHERIT_MODE}}.

### Step 3: Set up the report's Decision Log
Initialize a `decisions.jsonl` file in the report's Project storage (or `~/.claude/logs/decisions-[report-slug].jsonl` on Code).

### Step 4: Set up the report's Daily Brief seed
Configure the report's daily-brief skill with:
- Their top 3 active projects (from {{REPORTS_LIST}}).
- Their default sign-off.
- Their calendar reference.
- Their direct reports if any (cascading).

### Step 5: Validate the kit loaded
For each report's Project, run a smoke test: type `summarize my role and the skills available to me`. Expect the report to see their role, division, projects, and the four baseline skills + adds.

If the smoke test fails for any report, log the failure and surface to VP for re-provisioning.

### Step 6: Output the kit-load summary
```
Starter kit shipped: 5 reports.
Baseline skills loaded: 4 per report (email-drafter, daily-brief, decision-logger, F-05 Skill Builder).
Role-conditional adds: BIZ-03 to your two BD reports, F-04 + F-09 to your field lead (Foreman), full set to your HR or compliance lead (Office Manager).
Smoke test PASS: 5/5.
Total time: 12 minutes.
```

## Anti-patterns
- Pushing the same kit to every report regardless of role. {{STARTER_KIT_PER_REPORT}} is the override.
- Skipping the smoke test. Half the rollout failures get caught here.
- Loading more than 6 skills on day 1. Cognitive load spikes. Add more in week 2 via skill-share.
- Skipping F-05 Skill Builder. Without F-05, reports cannot extend the system; they become consumers, not builders.

## Audit
Append `{ "ts": ..., "skill": "starter-skill-kit", "reports": N, "baseline_loaded": N, "role_adds": {...}, "smoke_test_pass": N, "smoke_test_fail": [report_names] }` to {{AUDIT_LOG_LOCATION}}.
