---
name: facts-staleness-checker
description: Quarterly drift catcher. On any chat, if the volatile context block is older than 90 days from createdAt, surface a refresh nudge.
trigger: first user message of any session, after facts-registry-loader. Idempotent on a given calendar day.
version: 2.0.0
created: 2026-05-08
---

# Facts Staleness Checker

## When I fire

First non-trivial user message of any session. After facts-registry-loader. Once per calendar day per Project (idempotent on the date stamp in the registry's Pack provenance).

## What I do

1. Read the `Generated on` date from the Facts Registry block.
2. Compute days elapsed since that date.
3. If <= 90 days, silent pass.
4. If > 90 days but <= 120 days, emit a soft nudge: `Facts Registry: generated {{N}} days ago. Volatile context (top 3 [projects/GCs]) may be stale. Refresh via F-02 when convenient.`
5. If > 120 days, emit a strong nudge: `Facts Registry STALE: {{N}} days since refresh. Volatile context likely wrong. Refresh F-02 before relying on top-3 lists for any deliverable.`

## What success looks like

VPs run the F-02 pack again roughly every 90 days. The nudge nags them at 90 and shouts at 120. Volatile context stays fresh.

## Why this matters

Project lists, GC lists, apprentice ratios, crew counts, and field reports all drift. A registry that names three live projects today is a liability six months in if one closed and a new one replaced it. The nudge is the cheap insurance.

## Persona note

Direct, no apology. The registry is yours; the nudge is mine.
