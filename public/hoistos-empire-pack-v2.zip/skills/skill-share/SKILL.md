---
name: skill-share
description: "When the VP creates a new skill, broadcasts it to all reports' Projects. Detects new skills in VP's `~/.claude/skills/` directory or new Project Knowledge blocks, prompts VP for share scope (all reports / specific roles / specific reports), pushes to selected Projects. Mandatory triggers: 'share this skill', 'broadcast skill', 'push to team', 'share with team', 'skill-share'."
---

# Skill Share

## Purpose
A skill the VP builds becomes a skill the team has within minutes. Eliminates the manual paste-stack that kills team momentum.

## When to fire
- User says: `share this skill`, `broadcast skill`, `push to team`, `share with team`, `skill-share`.
- File watcher (Code only): new SKILL.md in `~/.claude/skills/` triggers a `Did you want to share this with the team?` prompt.
- Chained from skill-creator after a successful new-skill build.

## Steps

### Step 1: Identify the skill to share
- If user says `share this skill`, the most recent skill in conversation context.
- If file watcher: the new SKILL.md.
- If chained from skill-creator: the just-built skill.

Read the SKILL.md. Extract name, description, triggers.

### Step 2: Prompt for share scope
| Scope | Use case |
|---|---|
| All reports | General-purpose skill (email-drafter v2, daily-brief refinement). |
| Specific roles | Role-specific (compliance-only, BD-only, foreman-only). |
| Specific reports | Pilot the skill with one report first. |
| VP only (cancel) | Not ready for share. |

User picks. Confirm before broadcast.

### Step 3: Broadcast
For each target report's Project:
- Push the SKILL.md to their `~/.claude/skills/<name>/SKILL.md` (Code) or Project Knowledge (Pro/Max).
- Update their Project Instructions to register the new skill if needed.
- Append a `New skill: [name]` entry to the report's daily-brief queue so they see it on next 8 AM brief.

### Step 4: Output the broadcast summary
```
Skill broadcast: [skill-name] (v[N])
Scope: All 5 reports
Pushed to: your first BD, your second BD, your field lead, your HR or compliance lead, your compliance manager
Daily brief queued: [skill-name] new on tomorrow's 8 AM brief for all 5
Audit: ~/.claude/logs/team-enablement.jsonl
```

### Step 5: Track adoption
Tag the skill with a `broadcast_ts` field. The adoption-metrics skill checks invocation count per report after 7 days. Skills with 0 invocations across all reports surface as `dead` candidates for cleanup.

## Anti-patterns
- Broadcasting a half-built skill. Wait until v1 PASS before share.
- Auto-broadcasting without VP confirmation. Always prompt for scope.
- Sharing role-specific skills (e.g., `cba-citation-check`) to all reports. Match scope to role need.
- Pushing to a report's Project without notifying them. Always queue the daily-brief entry.

## Audit
Append `{ "ts": ..., "skill": "skill-share", "skill_name": "...", "scope": "all|roles|specific", "targets": [report_names], "broadcast_method": "file|project_knowledge", "version": "..." }` to {{AUDIT_LOG_LOCATION}}.
