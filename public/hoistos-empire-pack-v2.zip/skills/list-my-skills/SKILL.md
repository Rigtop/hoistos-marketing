---
name: list-my-skills
description: List every skill {{VP_NAME}} has installed in this Project (or in `~/.claude/skills/` on Code), with name, trigger phrase, last-used date, and one-line description. Triggers on phrases like "list my skills", "what skills do I have", "show my skill library", "skills inventory". Use whenever the user wants a roster of their skills, even if they do not say "list".
version: 2.0.0
created: 2026-05-08
---

# list-my-skills

## Mission

When {{VP_NAME}} asks for the inventory, scan all installed skills and return a table.

On Pro/Max: scan Project Knowledge for all sections that start with `## Custom skill:` or `## SKILL.md:` or YAML frontmatter blocks with `name:`. List each.

On Code: scan `~/.claude/skills/` directory. For each subdirectory, read the SKILL.md frontmatter, extract name, description, version, created date.

## Output format

| Skill name | Trigger phrase | Output format | Created | Description |
|---|---|---|---|---|
| `mech-draft-followup` | "draft followup" | email | 2026-05-08 | 4-line follow-up email to GC PM after coordination meeting |
| `bd-score-rfp` | "score this RFP" | table | 2026-05-09 | RFP fit scorer 1-10 |

If zero skills installed, say "no skills installed yet. Use the build-skill skill to create your first one."

## Refusal scope

If the user asks list-my-skills to also delete or modify a skill, refuse: "list only. Use a different skill or edit Project Knowledge directly to modify."

## Pack provenance

Generated from: foundation-05-skill-builder v2.0.0
Fingerprint: [SHA256 placeholder]
