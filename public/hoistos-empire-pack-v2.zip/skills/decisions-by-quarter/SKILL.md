---
name: decisions-by-quarter
description: Generate a quarterly rollup of Decision Log entries for {{VP_NAME}}. Triggers on phrases like "decisions by quarter", "quarterly decision rollup", "Q2 decisions", "rollup my log", "what did I decide last quarter". Use whenever the user wants a structured retrospective of their decisions across a fiscal or calendar quarter. Group by reason code, count by tag, surface contradictions.
version: 2.0.0
created: 2026-05-08
---

# decisions-by-quarter

## Mission

When {{VP_NAME}} asks for a quarterly rollup ("decisions by quarter", "Q2 rollup", "what did I decide last quarter"), pull all Decision Log entries from the requested quarter and produce a structured retrospective.

## Fiscal calendar

{{VP_NAME}}'s fiscal year ends {{VP_FY_END}}.

If {{VP_FY_END}} is "Nov-Oct" (your company default):
- Q1 = Nov 1 to Jan 31
- Q2 = Feb 1 to Apr 30
- Q3 = May 1 to Jul 31
- Q4 = Aug 1 to Oct 31

If {{VP_FY_END}} is "calendar year":
- Q1 = Jan to Mar
- Q2 = Apr to Jun
- Q3 = Jul to Sep
- Q4 = Oct to Dec

If the user says "last quarter" without specifying, infer from today's date.

## Output format

# Decisions: {{VP_NAME_FIRST}}, {{QUARTER_LABEL}} {{FISCAL_YEAR}}

## Counts
- Total entries: N
- DECISION: N
- CORRECTION: N
- POLICY: N
- CANONICAL: N

## Top tags
- Project: top 5 tags by count
- GC: top 5 tags by count
- Decision type: top 5 tags by count

## Contradictions or supersessions
List entries where a CORRECTION reason code reverses an earlier DECISION. Show both side by side.

## Five highest-impact decisions
Selected by a mix of dollar/schedule/personnel weight. One sentence each.

## Open loops
Entries tagged "follow-up required" or "TBD" that have not been logged as resolved.

## Construction-VP example

Input: "decisions by quarter, Q2 fiscal year 2026"
Output: a rollup matching the format above, grouped, counted, with contradictions surfaced. Useful for a Sunday review session or a CEO-and-VP sync.

## Pack provenance

Generated from: foundation-04-decision-log v2.0.0
Fingerprint: [SHA256 placeholder]
