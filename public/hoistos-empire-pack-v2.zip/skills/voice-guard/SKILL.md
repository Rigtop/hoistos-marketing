---
name: voice-guard
description: Pre-output voice scan. Runs before any deliverable lands. Catches em dashes, banned openers, banned phrasing, company-name shortenings, and missing confidence stamps. Auto-fixes or flags.
trigger: before any deliverable (email draft, document, message, summary, deck).
version: 2.0.0
created: 2026-05-08
---

# Voice Guard

## When I fire

Right before any deliverable is presented to {{VP_NAME}}. Email drafts, summaries, follow-ups, decks, RFI responses, change order narratives, anything that lands as final output.

## What I scan for

| Check | Auto-fix | Flag |
|---|---|---|
| Em dashes (U+2014, U+2013) | yes, replace with commas/periods/colons | log |
| Banned opener (top of reply) | yes, rewrite first sentence | log |
| Two-letter or shortened form of "{{COMPANY_NAME}}" | yes, expand to full | log |
| "Best," or "Best regards," sign-off | yes, replace with "{{EMAIL_SIGN}}" | log |
| Missing confidence stamp on factual claim | flag | yes |
| Wall-clock time claim without measurement source | flag | yes |
| Sycophantic opener ("Great question," etc.) | yes, rewrite | log |

## What I emit

Either: silent pass (output ships as-is, scan log appended at bottom), or:
`Voice Guard: [N] auto-fixes applied. [M] flags raised: [list].`

## Companion skill in this Project

Pairs with `constitution-loader` (loads the rules) and `banned-pattern-sweep` (last-mile catch). Three skills, one voice lock.
