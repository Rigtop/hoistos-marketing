---
name: decision-recall
description: |
  Companion skill for HoistOS Empire Pack v2. Source pack: mid-04-knowledge-search.md.
  This file is a placeholder. The canonical body lives inside the pack file in this bundle
  at packs/mid-04-knowledge-search.md, in the skill artifact section. Copy that body here, or
  re-run bundle-build.sh after the source pack adds an `Artifact: ~/.claude/skills/decision-recall/SKILL.md`
  fenced block.
install_path: ~/.claude/skills/decision-recall/SKILL.md
source_pack: packs/mid-04-knowledge-search.md
version: 2.0.0
---

# decision-recall

Open `packs/mid-04-knowledge-search.md` and follow Step 2 (Save the SKILL.md files locally).
The pack body is the source of truth. This stub exists so the bundle's `skills/` tree
is browsable and the install script has a path to copy from.
