---
name: validate-output
description: "Pre-delivery quality gate for any deliverable. Runs 9 checks before Claude presents the deliverable. Failures auto-remediate up to 2 attempts; persistent failures block delivery. Mandatory triggers: ANY deliverable ready to present, ANY file save, any draft, 'validate this', 'check my output', 'ready to send', 'sanity check', 'pre-delivery', 'before I send', 'before I ship', 'is this good', 'review this'."
---

# Validate Output

## Purpose
Catch the predictable failures (em-dashes, identity slips, name typos, routing misses, stale figures, weak ratings) before they reach the user. The user becomes the reader of finished work, not the editor of half-finished drafts.

## When to fire
- User says: "validate this," "check my output," "ready to send," "sanity check," "before I ship."
- Claude is about to present a draft email, proposal, brief, snapshot, SOP, RFI, or any deliverable matching `{{VALIDATE_FIRES_ON}}`.
- A pending file save is queued (Write/Edit/MultiEdit/NotebookEdit).

## Skip when
- User explicitly says "skip validation" or "ship as-is."
- Output is a chat-only response under 50 lines that is not classified as a deliverable.
- Trivial re-edits of files already validated in this session within the last 10 minutes.

## Steps

### Pre-step: emit visible token
Output `VALIDATION RUNNING` on its own line so the user sees the gate engage.

### Check 1: Em-dashes and en-dashes
- Grep deliverable content for U+2014 (em-dash) and U+2013 (en-dash).
- Acceptable in code blocks, file paths, quoted IDs.
- FAIL if present in narrative prose.
- On FAIL: replace with comma, period, colon, or split-sentence per surrounding context. Re-run check.

### Check 2: Identity
- Search for "CEO" near the user name. FAIL if present (user is COO, source: facts-registry.md).
- Search for the two-letter abbreviation of your company as a standalone token outside code blocks, IDs, quoted paths. FAIL if matched.
- Search for an employee count claim other than "90+" in public-facing content. FAIL if matched.
- Search for any office line phone number anywhere. FAIL (cell-only signature discipline).
- On FAIL: rewrite to canonical values from facts-registry.md. Re-run check.

### Check 3: Person names against the canonical list
- Extract every proper-noun pair matching `\b[A-Z][a-z]+ [A-Z][a-z]+\b` plus standalone first names that match a single first-name in the people list.
- For each, fuzzy-match against `{{PEOPLE_LIST}}` (Levenshtein distance threshold: 2).
- FAIL if name not found and not an obvious public figure (cite-context check: "as the New York Times reported" -> public figure context).
- On FAIL: output `UNVERIFIED NAME: [X]. Clarify who this is, or did you mean [closest match in people list]?` Hold delivery.

### Check 4: Routing (if a file save is pending)
- Compare target path against the routing-rules from F-01.
- FAIL if: path is `Outputs/` root with no subfolder, path creates a new top-level `Outputs/` folder, path is inside `Claude Workspace/` and not in the allowlist, path is a known shadow folder (`Outputs/<Your Company>/Financial`, `Outputs/<Your Company>/Compliance`, `Outputs/<Your Company>/Billing`).
- On FAIL: emit inline `Routing: row [N] ([classification]) → [correct path]` and route to the correct path. Re-run check.

### Check 5: Banned phrases (extended set)
- Scan for the banned-phrase list from Project Knowledge.
- Add: the banned openers and closers list, AI-assistant tropes, custom additions `{{CUSTOM_BANNED_PHRASES}}`.
- FAIL if any matched in narrative prose (excluded: code blocks, quoted citations).
- On FAIL: rewrite to plain-English equivalent. Re-run check.

### Check 6: Stale facts
- Cross-reference any cited figure (financial, project status, headcount, schedule-slip days) against:
  - F-04 Decision Log for last update timestamp on the related claim
  - facts-registry.md volatile-facts table
- FAIL if the figure does not have an `(as of [date])` adjacency, OR the date is older than the staleness threshold for the category:
  - Person role title: 90 days
  - Project status: 14 days
  - Financial figure: 30 days
  - Compliance figure: 7 days (tighter for compliance)
  - Forecast or projection: 60 days
- On FAIL: add `(as of [date], source: [X])` adjacency from the actual source date, OR replace the figure with a pointer (`See [source] for current [fact]`).

### Check 7: Self-rating threshold
- Invoke `self-rate` companion skill on the deliverable.
- FAIL if score < {{RATING_THRESHOLD}}.
- On FAIL: silent revise based on self-rate's line-by-line audit, re-rate, re-run.

### Check 8: Cold-start stamp present (One-Brain Gate, Principle 1)
- Required regex match in current session transcript: `^COLD-START:` line indicating Constitution + facts-registry + SESSION_BRIEFING were loaded at session open.
- Acceptable alternative: `^COLD-START FAILURE:` (logged failure, still better than silence).
- FAIL if neither present and the deliverable is non-trivial (≥50 lines, or a file save, or a Notion row, or an email draft).
- On FAIL: output `COLD-START MISSING: run cold-start-verify skill first, then retry validation.` Hold delivery.

### Check 9: Source-queried-before-factual-claim (One-Brain Gate, Principle 2)
- Extract factual claims from the deliverable: person names, project statuses, financial figures, policy statements, recent decisions.
- For each claim, scan the session transcript for a matching tool call (Notion fetch, file Read, RAG search, etc.).
- FAIL if claim exists with no corresponding source query in this session.
- Banned-phrase scan (case-insensitive): FAIL if deliverable contains "I think it is," "based on what I remember," "probably," "likely," "last I checked," "if I recall," in factual-claim context.
- On FAIL: query the source (`mcp__claude_ai_Notion__notion-fetch`, Read tool on canonical files, RAG search). Replace claim with sourced value. Re-run.

### After all checks PASS
- Emit one-line audit log: `Validator: 9/9 PASS [+ "fixed [X] on draft v1, presenting v2." if any check auto-remediated].`
- Append run record to `{{AUDIT_LOG_LOCATION}}`: `{ "ts": "ISO_TIME", "deliverable_hash": "SHA256_first_8", "checks_run": 9, "checks_passed": N, "remediations": M, "rating": X.X }`.
- Present the deliverable.

### After 2 remediation attempts and still failing
- Output `VALIDATOR HOLD: [check_id] persistently failing after 2 remediations. Showing the failing draft for your review.`
- Show the deliverable with the failing pattern highlighted.
- Wait for user instruction (revise, ship-anyway, discard).

## Authority
The self-verify discipline. Foundation 09 pack v2.0.0.
