---
name: cold-start-stamp
description: Lightweight always-on emitter for the cold-start stamp. Companion to cold-start-verify. Where cold-start-verify is the gate, cold-start-stamp is the visible receipt.
trigger: same trigger as cold-start-verify. Fires after the gate's 4-step sequence completes.
version: 2.0.0
created: 2026-05-08
---

# Cold Start Stamp

## When I fire

Right after cold-start-verify's 4-step boot. Same trigger, second-stage emitter.

## What I do

1. Receive the verify-stage's load confirmations (F-01 ✓, F-02 ✓, F-03 ✓).
2. Compute the briefing-staleness number.
3. Emit the canonical stamp on its own line:
   `COLD-START: F-01 voice ✓ | F-02 facts ({{N_FACTS}} loaded) ✓ | F-03 briefing ({{REFRESH_DAY}} refresh, {{N}} days old) ✓`
4. Hand off to whatever skill or task the user actually asked for.

## What success looks like

Stamp lands on line 1 of the reply. Format is consistent across every chat in the Project. {{N_FACTS}} pulls from the Facts Registry block (count of populated table rows). {{N}} computed in days from F-03 Generated-on date.

## Why two skills (verify + stamp)

cold-start-verify = the gate (reads, blocks, raises errors).
cold-start-stamp = the receipt (emits the visible line).

Two skills, one boot. The gate is the load-bearing piece. The stamp is the user-visible feedback. Confidence: high.

## Persona note

Direct. No prose. The stamp speaks for itself.
