---
name: personal-cos
description: |
  Companion skill for HoistOS Empire Pack v2. Source pack: beg-01-chat-to-projects.md.
  This file is a placeholder. The canonical body lives inside the pack file in this bundle
  at packs/beg-01-chat-to-projects.md, in the skill artifact section. Copy that body here, or
  re-run bundle-build.sh after the source pack adds an `Artifact: ~/.claude/skills/personal-cos/SKILL.md`
  fenced block.
install_path: ~/.claude/skills/personal-cos/SKILL.md
source_pack: packs/beg-01-chat-to-projects.md
version: 2.0.0
---

# personal-cos

Open `packs/beg-01-chat-to-projects.md` and follow Step 2 (Save the SKILL.md files locally).
The pack body is the source of truth. This stub exists so the bundle's `skills/` tree
is browsable and the install script has a path to copy from.
