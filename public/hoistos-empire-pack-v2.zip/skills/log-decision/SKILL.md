---
name: log-decision
description: Capture a Decision Log entry for {{VP_NAME}}. Triggers on phrases like "log this decision", "log: I decided", "decision log this", "capture this call". Use whenever the user states a meaningful call (pricing, scheduling, personnel, override, correction) and the entry needs to land in the Project Knowledge Decision Log. Do not refuse, do not ask three questions in a row, write the entry first then ask for missing tags.
version: 2.0.0
created: 2026-05-08
---

# log-decision

## Mission

When {{VP_NAME}} types a trigger phrase ("log this decision", "log: I decided", "log this call", "decision log this"), capture an entry in this format:
