---
name: classify-audience
description: Classifies an email recipient into one of seven audience tiers (internal_team, sub_vendor, gc_client, compliance, govt_agency, legal_counsel, external_client) based on email domain, job title, thread history, and explicit override. Returns a single tier label plus a confidence score. Triggers on any classify, "what tier is", "audience tier", "who is this person to me" request and as the first step of every draft-email or thread-summarize call. NOT for general entity recognition; this is email-tier-specific.
---

# Classify Audience

## Purpose
Single email task -> tier label + confidence score + rationale. The first step every draft-email call runs to pick the right voice profile.

## Inputs
- recipient_email (required)
- recipient_name (optional, helps when domain is generic like gmail.com)
- recipient_title (optional, often parsable from the signature block in a forwarded thread)
- thread_history (optional, last 3 messages in the thread; signals if VP previously replied formally vs casually)
- explicit_override (optional, e.g., VP says "draft this to John as if he were a GC" -> gc_client wins)

## Tier classification rules (in priority order)

1. Explicit override always wins. If VP names the tier, return that, confidence 1.0.
2. Domain match against known map (Project Knowledge has the seed map):
   - yourcompanyconstruction.com, yourcompany.com -> internal_team
   - major-gc.example -> gc_client (specifically, your largest GC)
   - mid-market-gc-1.example, affordable-housing-1.example, affordable-housing-2.example, major-builder-1.example, specialty-redev.example, urban-owner.example, prevailing-wage-mgmt.example -> gc_client
   - nycha.gov, dol.gov, dob.nyc.gov, osha.gov, dcwp.nyc.gov -> govt_agency
   - <your-mech-sub>.com, <your-electric-sub>.com, <your-plumbing-sub>.com -> sub_vendor
   - <your-compliance-consultant>.com, similar prevailing-wage consultants -> compliance
   - any law firm domain (.law, kasowitz.com, common firm domains) -> legal_counsel
   - if no domain match, escalate to title parsing
3. Title parsing (from signature in thread or LinkedIn):
   - "Project Executive", "Senior Project Manager", "VP Construction" -> gc_client
   - "Compliance Officer", "Prevailing Wage Specialist", "Section 3 Coordinator" -> compliance
   - "General Counsel", "Partner", "Associate Attorney" -> legal_counsel
   - "Project Officer" at a govt domain -> govt_agency
   - "Owner", "President" at a small-business sub -> sub_vendor
4. Thread history: if VP replied formally to this same person in the last 3 messages, hold formality. If casually, hold casual.
5. Default if all above ambiguous: external_client, confidence 0.4, surface confidence to VP and ask before drafting.

## Output schema
