---
name: email-scan
description: "Inbox scanner. Pulls unread + last 48 hours of read threads, deduplicates by threadId, filters out non-actionable noise (newsletters, automated, CC-only, calendar pings, threads where user replied last). Returns a clean actionable set for downstream classification. Mandatory triggers: 'check my email', 'scan inbox', 'any new emails', 'what needs a reply', 'inbox', 'morning email', 'run my morning routine' (chain entry)."
---

# Email Scan

## Purpose
Pull the actionable inbox set in one pass. Filter out noise. Hand off to email-triage-rank for classification.

## When to fire
- User says: `check my email`, `scan inbox`, `any new emails`, `what needs a reply`, `inbox`, `morning email`.
- Chained inside `morning-email-routine` as Step 1.

## Steps

### Step 1: Load context in parallel
- Email Playbook (F-10) at `~/Desktop/AI Architecture/Claude Workspace/Global/Email Playbook.md` if present, OR Project Knowledge block if Pro tier.
- Today's calendar via `gcal_list_events` (or Cowork calendar connector).
- Active projects list from {{ACTIVE_PROJECTS}}.

### Step 2: Pull the candidate set
Run two Gmail searches in parallel via `gmail_search_messages`:
1. `is:unread` (max 50 results)
2. `in:inbox is:read newer_than:2d -in:sent` (max 50 results)

### Step 3: Deduplicate by threadId
Some emails appear in both queries. Keep one entry per thread, using the most recent message.

### Step 4: Read full threads
For each unique thread, use `gmail_read_thread` to get full conversation history. Required because:
- If user's last message is most recent, drop (already replied).
- Full thread context is needed for downstream drafting.
- Detect escalation level for collections threads.
- Calculate wait-time = now - last-non-user-message-timestamp.

### Step 5: Filter out non-actionable
Drop:
- Automated notifications (Google, GitHub, Calendly, marketing newsletters, system alerts).
- Threads where user replied last.
- CC-only threads where user is not in TO and no action requested of them.
- Calendar invites that are purely informational (no RSVP needed or already accepted).

### Step 6: Cross-reference calendar
For each remaining thread:
- If sender has a meeting with user today: tag `meeting_today` (will bump urgency in next skill).
- If thread references a meeting that was cancelled or rescheduled: tag `meeting_resolved` (will bump down).

### Step 7: Output the actionable set
Return a JSON-shaped list (or markdown table for chat tier):

```
[
  { "threadId": "...", "from": "your top client contact", "subject": "RE: your interior renovation project - schedule slip", "wait_hours": 28, "tier_hint": "gc_client", "tags": ["project:interior_reno", "meeting_today"], "last_msg_summary": "..." },
  ...
]
```

Hand off to email-triage-rank.

## Skip when
- User explicitly says `skip scan` or asks for a single-email draft (hand off to email-draft).
- Last scan ran less than 5 minutes ago (use cached set, warn user).

## Anti-patterns
- Auto-creating Notion People rows for new senders. Per the email-scan SKILL.md, defer to the Entity Creation Protocol with explicit approval.
- Skipping the calendar cross-reference. Calendar context is what separates triage from a dumb filter.
- Reading only the last message in a thread. Full thread or no draft.

## Audit
Append `{ "ts": ..., "skill": "email-scan", "candidates": N, "actionable": N, "filtered": N }` to {{AUDIT_LOG_LOCATION}}.
