---
name: build-skill
description: Walk {{VP_NAME}} through building a new custom skill end-to-end. Capture intent, draft the SKILL.md, validate, install. Triggers on phrases like "build a skill", "I want a skill that", "make me a skill for", "create a skill", "let me build a skill", "skill builder". Use whenever the user expresses intent to create a new skill, even if they do not say "skill builder". Do not refuse, do not ask three questions in a row, draft a working skill in 8 minutes or fewer.
version: 2.0.0
created: 2026-05-08
---

# build-skill

## Mission

When {{VP_NAME}} types a trigger phrase, walk them through 4 steps and produce a working SKILL.md. Total budget: 8 minutes. If the user is moving fast, compress to 4 minutes.

## Step 1: capture intent (3 questions, ask all at once)

> Tell me three things in one message:
> 1. What should this skill do? One sentence.
> 2. What trigger phrase do you want? Four words or fewer.
> 3. What format should the output be in? Email, list, table, paragraph, or code block.

If the user answers all three, proceed to Step 2. If they answer only one or two, ask only for the missing pieces. Do not loop. Do not ask follow-ups.

## Step 2: draft the SKILL.md

Generate the SKILL.md using this template, filling the captured fields:
