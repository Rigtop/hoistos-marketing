---
name: morning-email-routine
description: "The 15-minute morning email routine, productized. Chains email-scan + email-triage-rank + email-draft into one flow. Outputs a triage dashboard, drafts the top {{MORNING_ROUTINE_MODE}} HIGH items, queues all as Gmail drafts, never auto-sends. Mandatory triggers: 'run my morning routine', 'morning email', 'morning routine', 'check inbox and draft', 'do my email', 'inbox cleanup', '8 am routine'."
---

# Morning Email Routine

## Purpose
The chain skill. One command, four steps, 4-to-15 minutes of VP time, every morning.

## When to fire
- User says: `run my morning routine`, `morning email`, `morning routine`, `check inbox and draft`, `do my email`, `inbox cleanup`, `8 am routine`.
- Time-of-day heuristic: between 7 AM and 10 AM local on a weekday, if user just opened a session and has not stated other intent.

## Steps

### Step 1: Pre-flight
- Load the BIZ-03 Project Knowledge block.
- Load Email Playbook (F-10).
- Load Facts Registry (F-02).
- Confirm Gmail connector is live. If not, prompt user to reconnect.
- Note start_ts.

### Step 2: Run email-scan
Fire the email-scan skill. Get the actionable thread set.

If empty: `Inbox clear. No actionable threads in the last 48 hours. Total time: [N]s.` Log run, exit.

### Step 3: Run email-triage-rank
Fire the email-triage-rank skill on the actionable set. Get the ranked dashboard.

### Step 4: Present the dashboard
Output the dashboard table to the user. Format per BD Training Session 3 standard:

```
Morning Email Triage [date]
Total actionable: 9 threads
HIGH: 3 / MEDIUM: 4 / LOW: 2

| Urgency | From | Subject | Waiting | Tier | Action |
|---|---|---|---|---|---|
| HIGH | ... | ... | ... | ... | ... |
| ... |

Drafting top {{MORNING_ROUTINE_MODE}}...
```

### Step 5: Run email-draft on the top {{MORNING_ROUTINE_MODE}} HIGH items in parallel
For each, classify tier, draft per F-10 voice fingerprint, run F-09 pre-send-email-gate, call mcp__claude_ai_Gmail__create_draft.

If a draft fails the validator after 2 remediation attempts, hold and surface to user with the FAIL reason.

If the draft requires a decision the VP has not stated (`the carpentry add was 18% margin not 22%, do we hold the line or concede`), surface the question NOT a guess. Per the self-verify discipline.

### Step 6: Output the routine summary
```
Routine: scanned 47 threads, 9 actionable, 3 HIGH / 4 MEDIUM / 2 LOW.
Drafted 3 HIGH items: 
  - your top client contact (your largest GC, your interior renovation) [PASS, ready to send]
  - your GC contact (Related, Invoice #4521) [PASS, ready to send]
  - a GC PM (Turner, your largest active project Scope) [HOLD: decision needed on your prevailing-wage project pricing baseline]
Queued 4 MEDIUM as drafts.
2 LOW dismissed.
Total time: 3m 47s.
Audit: ~/.claude/logs/morning-email.jsonl
```

### Step 7: Hand off
Tell the user: `Open Gmail Drafts. Review the 7 drafts. The a GC PM draft needs your call on the carpentry margin question. Hit send when ready.`

## Anti-patterns
- Sending. The chain never sends. Drafts only.
- Drafting MEDIUM items in dashboard-first mode. Wait for user pick.
- Skipping the validator on chained drafts. Validator fires on every draft, every time.
- Quietly drafting decisions the VP must make. Surface the decision. Hold the draft.

## Audit
Append `{ "ts_start": ..., "ts_end": ..., "skill": "morning-email-routine", "scanned": N, "actionable": N, "high": H, "medium": M, "low": L, "drafts_created": D, "decisions_held": K }` to {{AUDIT_LOG_LOCATION}}.

## Triggers (full)
- `run my morning routine`
- `morning email`
- `morning routine`
- `check inbox and draft`
- `do my email`
- `inbox cleanup`
- `8 am routine`
- `9 am routine`
- `start my day`
- `clear my inbox`

## Pack provenance
- Pack: hoistos-biz-03-email-triage-responder v2.0.0
- Fingerprint: biz-03-email-triage-responder-v2.0.0
- Companion to: F-01, F-02, F-09, F-10.
- Authority: the self-verify discipline, the compliance-claim-verification discipline, HTML formatting on internal team emails, plain-language instructional emails, plain-text compliance threads, the world-class-expert voice contract, the cell-only signature discipline, the email-playbook pre-send discipline.
