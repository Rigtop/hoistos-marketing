---
name: file-search
description: |
  Companion skill for HoistOS Empire Pack v2. Source pack: beg-02-desktop-organizer.md.
  This file is a placeholder. The canonical body lives inside the pack file in this bundle
  at packs/beg-02-desktop-organizer.md, in the skill artifact section. Copy that body here, or
  re-run bundle-build.sh after the source pack adds an `Artifact: ~/.claude/skills/file-search/SKILL.md`
  fenced block.
install_path: ~/.claude/skills/file-search/SKILL.md
source_pack: packs/beg-02-desktop-organizer.md
version: 2.0.0
---

# file-search

Open `packs/beg-02-desktop-organizer.md` and follow Step 2 (Save the SKILL.md files locally).
The pack body is the source of truth. This stub exists so the bundle's `skills/` tree
is browsable and the install script has a path to copy from.
