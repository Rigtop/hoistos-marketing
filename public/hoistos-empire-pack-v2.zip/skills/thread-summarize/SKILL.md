---
name: thread-summarize
description: Summarizes a long email thread in three bullets max. Pulls the latest 3 messages, extracts the live ask, the live blocker, and the live next step. Returns a tier label (from classify-audience) so the next draft-email call can pick the right voice. Triggers on "summarize this thread", "what does this thread say", "give me the bullets", "TL;DR this", "what's the ask", any forwarded thread longer than 5 messages, and as a precursor to draft-email when the thread is too long to read every message.
---

# Thread Summarize

## Purpose
The VP gets a 19-message Gmail thread. Reading it eats 8 minutes. The bullets eat 30 seconds. Three bullets, max.

## Output schema
